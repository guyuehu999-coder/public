
import { Employee, PhaseStep, Project, FeatureMetric, ReviewStat, PerformanceSnapshot } from './types';

// Mock Employees with Sub-teams
export const MOCK_EMPLOYEES: Employee[] = [
  {
    id: 'PM001',
    name: '陈萨拉',
    role: 'Product Manager',
    subTeam: '交易中台组',
    businessLine: '核心电商',
    level: '资深',
    avatar: 'https://picsum.photos/id/101/64/64',
    metrics: { primary: 98.5, secondary: 12, trend: 'up', trendValue: 5.2 },
    // Updated metrics: Removed Revenue, Added Conversion & Usage
    details: { '核心转化率': '32.5%', '功能访问量': '240k', 'S级项目交付': '100%' }
  },
  {
    id: 'PM002',
    name: '迈克·罗',
    role: 'Product Manager',
    subTeam: '用户增长组',
    businessLine: '用户增长',
    level: '中级',
    avatar: 'https://picsum.photos/id/102/64/64',
    metrics: { primary: 92.0, secondary: 9, trend: 'up', trendValue: 1.1 },
    details: { '核心转化率': '15.2%', '功能访问量': '12.5k', 'S级项目交付': '100%' }
  },
  {
    id: 'PM003',
    name: '李杰西',
    role: 'Product Manager',
    subTeam: '商业化组',
    businessLine: '商业化',
    level: '初级',
    avatar: 'https://picsum.photos/id/103/64/64',
    metrics: { primary: 85.5, secondary: 5, trend: 'down', trendValue: 2.3 },
    details: { '核心转化率': '2.1%', '功能访问量': '8.5k', 'S级项目交付': '80%' }
  },
  {
    id: 'PM004',
    name: '张伟',
    role: 'Product Manager',
    subTeam: '交易中台组',
    businessLine: '核心电商',
    level: '中级',
    avatar: 'https://picsum.photos/id/104/64/64',
    metrics: { primary: 96.0, secondary: 10, trend: 'stable', trendValue: 0.2 },
    details: { '核心转化率': '31.0%', '功能访问量': '210k', 'S级项目交付': '100%' }
  },
   {
    id: 'UX001',
    name: '金大卫',
    role: 'UX Designer',
    subTeam: '体验设计组',
    businessLine: '体验设计部',
    level: '资深',
    avatar: 'https://picsum.photos/id/201/64/64',
    metrics: { primary: 99.0, secondary: 9.2, trend: 'up', trendValue: 0.5 },
    details: { '设计验收通过率': '99%', '体验满意度': '4.9/5', '需求响应': '0.5h' }
  }
];

// High Value Projects (S/A Grade)
export const MOCK_PROJECTS: Project[] = [
  { 
    id: 'P1', 
    name: '双11大促核心交易链路重构', 
    grade: 'S', 
    owner: '陈萨拉', 
    subTeam: '交易中台组', 
    status: 'In Progress', 
    progress: 75, 
    businessValue: 98,
    weeklyFocus: '本周五前完成全链路压测，输出性能报告' 
  },
  { 
    id: 'P2', 
    name: '新用户首单转化漏斗优化', 
    grade: 'A', 
    owner: '迈克·罗', 
    subTeam: '用户增长组', 
    status: 'Completed', 
    progress: 100, 
    businessValue: 88 
  },
  { 
    id: 'P3', 
    name: '商业化广告智能投放系统', 
    grade: 'S', 
    owner: '李杰西', 
    subTeam: '商业化组', 
    status: 'Delayed', 
    progress: 40, 
    businessValue: 92,
    weeklyFocus: '与算法团队对齐推荐模型 V2.0 接口字段'
  },
  { 
    id: 'P4', 
    name: '跨境支付网关接入', 
    grade: 'A', 
    owner: '张伟', 
    subTeam: '交易中台组', 
    status: 'In Progress', 
    progress: 60, 
    businessValue: 85 
  },
];

// NEW: Performance History Snapshots (Data Persistence)
export const MOCK_PERFORMANCE_HISTORY: PerformanceSnapshot[] = [
  {
    id: 'SNAP-PM001-2023-Q4',
    employeeId: 'PM001', // Sarah Chen
    period: '2023 Q4',
    roleSnapshot: 'Product Manager (Senior)',
    teamSnapshot: '交易中台组',
    finalGrade: 'S',
    metrics: [
      { label: '业务结果达成率', value: '102%', target: '100%', achievementRate: 102 },
      { label: 'S级项目交付数', value: 2, target: 2, achievementRate: 100 },
      { label: '线上故障数', value: 0, target: 0, achievementRate: 100 },
    ],
    keyProjects: [
      { name: '收银台 3.0 重构', grade: 'S', result: '提前上线，转化率提升 5%' },
      { name: '年度账单功能', grade: 'A', result: '按期交付' }
    ]
  },
  {
    id: 'SNAP-PM001-2023-Q3',
    employeeId: 'PM001', // Sarah Chen
    period: '2023 Q3',
    roleSnapshot: 'Product Manager (Senior)',
    teamSnapshot: '用户增长组 (轮岗)',
    finalGrade: 'A',
    metrics: [
      { label: '业务结果达成率', value: '95%', target: '90%', achievementRate: 105 },
      { label: 'S级项目交付数', value: 1, target: 1, achievementRate: 100 },
    ],
    keyProjects: [
      { name: '新人大礼包策略', grade: 'A', result: '上线后新客成本降低 10%' }
    ]
  },
  {
    id: 'SNAP-PM002-2023-Q4',
    employeeId: 'PM002', // Mike Luo
    period: '2023 Q4',
    roleSnapshot: 'Product Manager (Mid)',
    teamSnapshot: '用户增长组',
    finalGrade: 'A',
    metrics: [
      { label: '业务结果达成率', value: '98%', target: '90%', achievementRate: 108 },
      { label: 'A级项目交付数', value: 3, target: 3, achievementRate: 100 },
    ],
    keyProjects: [
      { name: '春节红包雨活动', grade: 'A', result: '日活峰值突破历史新高' }
    ]
  },
  {
    id: 'SNAP-UX001-2023-Q4',
    employeeId: 'UX001', // David Kim
    period: '2023 Q4',
    roleSnapshot: 'UX Designer (Senior)',
    teamSnapshot: '体验设计组',
    finalGrade: 'S',
    metrics: [
      { label: '设计验收通过率', value: '100%', target: '95%', achievementRate: 105 },
      { label: '用户体验贡献值', value: 'High', target: 'Medium', achievementRate: 120 },
    ],
    keyProjects: [
      { name: 'Design System 2.0', grade: 'S', result: '全站组件覆盖率提升至 80%' }
    ]
  }
];

export const PRODUCT_DASHBOARD_DATA = {
  // New: Team specific business metrics with history for sparklines
  teamBusinessMetrics: [
    { 
      label: '团队负责业务GMV', 
      value: '¥1.2M', 
      change: '+12.5%', 
      trend: 'up',
      data: [100, 105, 102, 108, 115, 120] 
    },
    { 
      label: '核心路径转化率', 
      value: '28.4%', 
      change: '+2.1%', 
      trend: 'up',
      data: [25, 25.5, 26, 26.8, 27.5, 28.4] 
    },
    { 
      label: '功能渗透率', 
      value: '45.0%', 
      change: '-1.5%', 
      trend: 'down',
      data: [46, 47, 46.5, 46, 45.5, 45] 
    },
    { 
      label: '用户NPS评分', 
      value: '48', 
      change: '+5', 
      trend: 'up',
      data: [40, 42, 43, 42, 45, 48] 
    }
  ],
  featureTrends: {
    // 模拟 "交易管理平台" 的整体数据
    overall: { usageRate: 94.2, wow: 1.5, mom: 5.8 }, 
    chartData: Array.from({ length: 30 }, (_, i) => ({
      day: `5/${i + 1}`,
      value: 80 + Math.random() * 20 + (i * 0.2) // Higher usage baseline for transaction tools
    })),
    // 映射到您的五个核心业务模块 - NOW WITH INDIVIDUAL HISTORY
    subTeams: [
      { 
        name: '产品选购', 
        rate: 88.5, 
        trend: 4.2,
        history: [80, 82, 81, 85, 87, 88.5, 89]
      },
      { 
        name: '在线咨询', 
        rate: 76.3, 
        trend: 12.1,
        history: [60, 65, 68, 70, 72, 75, 76.3] // Steep growth
      }, 
      { 
        name: '在线报价', 
        rate: 92.7, 
        trend: 1.5,
        history: [90, 91, 91.5, 92, 92, 92.5, 92.7]
      },
      { 
        name: '在线结算', 
        rate: 99.8, 
        trend: 0.1,
        history: [99, 99.2, 99.1, 99.5, 99.7, 99.8, 99.8] // Stable
      }, 
      { 
        name: '在线评论', 
        rate: 65.4, 
        trend: -2.3,
        history: [68, 67, 67, 66, 65, 65.2, 65.4]
      }, 
    ],
    owners: [
      { rank: 1, name: '陈萨拉', count: 2, rate: 96.3, trend: 2 },
      { rank: 2, name: '张伟', count: 2, rate: 94.6, trend: 1 },
      { rank: 3, name: '王强', count: 1, rate: 89.1, trend: 0 },
    ]
  },
  projectDelivery: {
    // New Process and Quality Stats
    processStats: {
        pendingReview: 4,  // 待评审
        inDevelopment: 8,  // 开发中
        inTesting: 3,      // 测试中
        delayed: 2         // 严重延期
    },
    qualityStats: {
        avgFeedback: 4.8,
        bugDensity: 0.12, // per 1k lines or feature
        reopenRate: 2.5   // %
    },
    stats: { sTotal: 3, sDone: 1, aTotal: 6, aDone: 4, rate: 62.5, avgScore: 4.8 },
    projects: [
      { grade: 'S', name: '智能报价引擎 2.0', owner: '陈萨拉', status: '测试中', progress: 85, feedback: '-' },
      { grade: 'S', name: '全球聚合支付网关', owner: '张伟', status: '已投产', progress: 100, feedback: '5.0' },
      { grade: 'S', name: '选购页千人千面重构', owner: '陈萨拉', status: '待评审', progress: 10, feedback: '-' },
      { grade: 'A', name: '咨询IM系统迁移', owner: '王强', status: '延期', progress: 40, feedback: '-' },
      { grade: 'A', name: '评论反垃圾模型升级', owner: '李明', status: '开发中', progress: 60, feedback: '-' },
    ],
    milestones: { total: 32, onTime: 25, rate: 78.1, delays: { req: 5, res: 1, other: 1 } }
  },
  reviewQuality: {
    stats: { total: 18, passed: 14, rate: 77.8, cycle: 2.5, overdue: 1 },
    byGrade: [
      { grade: 'S', total: 4, passed: 3, rate: 75 },
      { grade: 'A', total: 10, passed: 8, rate: 80 },
      { grade: 'B', total: 4, passed: 3, rate: 75 },
    ],
    byOwner: [
      { rank: 1, name: '陈萨拉', total: 6, rate: 83, cycle: 1.8 },
      { rank: 2, name: '张伟', total: 5, rate: 80, cycle: 2.2 },
      { rank: 3, name: '王强', total: 4, rate: 75, cycle: 3.5 },
    ],
    decisions: [
      { name: '报价策略配置后台评审', date: '2024/5/22', result: 'Passed', approver: '产品总监' },
      { name: '收银台UI改版交互评审', date: '2024/5/20', result: 'Revise', approver: '设计总监' },
      { name: 'IM消息路由逻辑评审', date: '2024/5/18', result: 'Passed', approver: '架构师' },
    ]
  }
};

// 5-Step Logic: Define Metrics -> Clarify Data -> Design Dashboard -> Extract Ranking -> Design Leaderboard
export const IMPLEMENTATION_PHASES: PhaseStep[] = [
  { 
    title: "1. 定义核心指标体系", 
    status: "completed", 
    progress: 100,
    items: [
        "业务目标对齐：明确公司级目标（如营收增长、体验提升），拆解为产品/设计岗核心价值。", 
        "指标初定义：PM聚焦“业务结果+交付质量”，UX聚焦“设计成果+还原度”。", 
        "SMART原则量化：输出第一版《部门关键绩效指标字典》草案。"
    ] 
  },
  { 
    title: "2. 明确数据口径与取数", 
    status: "completed", 
    progress: 100,
    items: [
        "多源数据地图梳理：明确项目管理数据（如Bizflow）、业务经营数据（如BI系统/Excel）与用户行为数据的分布。", 
        "指标口径标准化：针对不同业务线的多样化指标，定义统一的计算公式与聚合逻辑。", 
        "数据接入方案评估：确定各指标的获取方式（API对接、中间表同步或人工填报）。"
    ] 
  },
  { 
    title: "3. 绩效可视化看板设计", 
    status: "in-progress", 
    progress: 80,
    items: [
        "管理层驾驶舱：搭建部门总览视图，监控全盘业务转化与核心项目进度。", 
        "团队与个人看板：开发产品组/个人工作台，实现指标下钻与过程透明化。", 
        "数据可视化实现：完成折线图、漏斗图等核心图表组件的开发与联调。"
    ] 
  },
  { 
    title: "4. 核心排行指标抽取", 
    status: "pending", 
    progress: 0,
    items: [
        "北极星指标甄选：从看板中提炼最具横向对比价值的“可排行指标”。", 
        "权重与算法微调：确定 PM 业务结果 vs 交付量的权重 (建议 6:4)。", 
        "榜单规则公示：向全员宣贯排名逻辑，确保规则公平透明。"
    ] 
  },
  { 
    title: "5. 部门业绩排行榜构建", 
    status: "pending", 
    progress: 0,
    items: [
        "排行榜系统落地：上线业绩排行榜功能，支持按岗位、职级、业务线筛选。", 
        "全员覆盖验证：确保 100% 业务团队（含所有中台与业务组）数据上榜。", 
        "常态化运营：建立每日自动更新机制，实现业绩可视化与正向激励。"
    ] 
  }
];

// --- SECTION 1: BUSINESS CONVERSION METRICS (Updated) ---
export const MANAGEMENT_OVERVIEW_DATA = {
  // Data for different time ranges
  metricsMap: {
    day: [
      { name: '线上交易转化率', value: '3.9%', change: '+0.1%', type: 'rate', desc: '昨日数据' },
      { name: '线上账号注册数', value: '450', change: '+12.5%', type: 'count', desc: '昨日新增' },
      { name: '核心工具使用率', value: '32.1%', change: '+1.5%', type: 'rate', desc: '活跃/总访问' },
      { name: '支付成功率', value: '99.9%', change: '0.0%', type: 'rate', desc: '实时监控' },
    ],
    month: [
      { name: '线上交易转化率', value: '3.8%', change: '+0.5%', type: 'rate', desc: '本月累计' },
      { name: '线上账号注册数', value: '12,500', change: '+8.2%', type: 'count', desc: '本月累计' },
      { name: '核心工具使用率', value: '28.5%', change: '+2.3%', type: 'rate', desc: '月均活跃' },
      { name: '支付成功率', value: '99.9%', change: '0.0%', type: 'rate', desc: '月度稳定性' },
    ],
    year: [
      { name: '线上交易转化率', value: '3.5%', change: '+1.2%', type: 'rate', desc: '年度平均' },
      { name: '线上账号注册数', value: '150k', change: '+25.0%', type: 'count', desc: '年度累计' },
      { name: '核心工具使用率', value: '26.0%', change: '+5.5%', type: 'rate', desc: '年度平均' },
      { name: '支付成功率', value: '99.8%', change: '+0.1%', type: 'rate', desc: '年度SLA' },
    ]
  },
  trendDataMap: {
    day: Array.from({ length: 24 }, (_, i) => ({ label: `${i}:00`, '转化率': (3 + Math.random()).toFixed(2), '注册数': Math.floor(Math.random() * 50) })),
    month: Array.from({ length: 30 }, (_, i) => ({ label: `${i + 1}日`, '转化率': (3.2 + Math.random() * 0.8).toFixed(2), '注册数': Math.floor(300 + Math.random() * 150) })),
    year: Array.from({ length: 12 }, (_, i) => ({ label: `${i + 1}月`, '转化率': (3 + Math.random()).toFixed(2), '注册数': Math.floor(8000 + Math.random() * 4000) })),
  },
  aiPredictions: {
    day: "AI 预测：今日下午 14:00 - 16:00 将迎来工具使用高峰，预计并发量增长 15%。建议提前检查服务器负载。",
    month: "AI 预测：基于当前增长趋势，本月注册数有望突破 1.4 万（环比增长 10%），主要是受“企业认证”功能优化驱动。",
    year: "AI 预测：年度交易转化率预计将在 Q4 达到 4.2% 的峰值，建议在 Q3 加大对“在线结算”模块的资源投入以承接流量。"
  }
};

// --- SECTION 2: CORE FEATURE USAGE & JOURNEY (Updated) ---
export const COCKPIT_USAGE_DATA = {
  // New User Journey Data
  userJourney: [
    { stage: '全站访问 (Visit)', count: '1.2M', conversion: '100%', trend: 'up' },
    { stage: '功能浏览 (Browse)', count: '850k', conversion: '70.8%', trend: 'up' },
    { stage: '核心交互 (Interact)', count: '320k', conversion: '37.6%', trend: 'down' }, // e.g. Quote, Cart
    { stage: '业务转化 (Convert)', count: '45k', conversion: '14.1%', trend: 'up' }, // e.g. Order, Pay
  ],
  summary: [
    { label: '总功能点击量', value: '1.2M', trend: 'up', change: '5.3%' },
    { label: '日均活跃用户 (DAU)', value: '45.2k', trend: 'up', change: '8.1%' },
    { label: '人均使用时长', value: '12m', trend: 'down', change: '2.1%' },
  ],
  // All 4 Platforms Details
  platformDetails: [
    {
      name: '交易管理平台',
      color: 'blue',
      features: [
        { name: '产品选购', pv: '240k', uv: '45k', clickRate: '12%' },
        { name: '在线报价', pv: '120k', uv: '12k', clickRate: '24%' },
        { name: '在线结算', pv: '85k', uv: '10k', clickRate: '85%' },
      ]
    },
    {
      name: '客户管理平台',
      color: 'purple',
      features: [
        { name: '企业认证', pv: '32k', uv: '8k', clickRate: '45%' },
        { name: '发票管理', pv: '15k', uv: '5k', clickRate: '32%' },
        { name: '账号权限', pv: '10k', uv: '3k', clickRate: '15%' },
      ]
    },
    {
      name: '服务与工具平台',
      color: 'emerald',
      features: [
        { name: 'Live Chat', pv: '55k', uv: '20k', clickRate: '60%' },
        { name: 'Design Center', pv: '25k', uv: '5k', clickRate: '18%' },
        { name: '售后工单', pv: '12k', uv: '8k', clickRate: '95%' },
      ]
    },
    {
      name: '资源与社区平台',
      color: 'orange',
      features: [
        { name: '技术文档', pv: '150k', uv: '60k', clickRate: '40%' },
        { name: '社区论坛', pv: '80k', uv: '15k', clickRate: '8%' },
        { name: '培训视频', pv: '45k', uv: '10k', clickRate: '22%' },
      ]
    },
  ]
};

// --- SECTION 3: REVIEWS & PROJECTS (Updated) ---
export const REVIEW_OVERVIEW_DATA = {
  stats: [
    { label: '发起评审总数', value: 128, unit: '次' },
    { label: '一次通过数', value: 92, unit: '次' },
    { label: '评审驳回数', value: 36, unit: '次' },
  ],
  passRate: 71.8, // %
  avgDuration: 2.5, // days
  trend: 'up' // vs last month
};

export const COCKPIT_PROJECT_STATS = {
  overview: {
    sClassCount: 8,
    sClassDone: 3,
    aClassCount: 15,
    aClassDone: 8,
    onTimeRate: '82%',
    delayCount: 3
  },
  keyProjects: [
    { name: '双11大促交易链路重构', grade: 'S', owner: '陈萨拉', status: '进行中', progress: 75, risk: 'Low', date: '2024-06-30' },
    { name: '商业化广告智能投放', grade: 'S', owner: '李杰西', status: '延期', progress: 40, risk: 'High', date: '2024-05-20' },
    { name: '全球聚合支付接入', grade: 'S', owner: '张伟', status: '已完成', progress: 100, risk: 'None', date: '2024-05-10' },
    { name: '新用户首单漏斗优化', grade: 'A', owner: '迈克·罗', status: '已完成', progress: 100, risk: 'None', date: '2024-05-15' },
    { name: '社区反垃圾模型', grade: 'A', owner: '李明', status: '进行中', progress: 60, risk: 'Medium', date: '2024-07-15' },
  ]
};

// Placeholder for backward compatibility if needed, but we will use BUSINESS_KPI_STATS in cockpit
export const DEPT_STATS = [
  { label: 'S级项目交付率', value: '92.5%', target: '90%', status: 'success' },
  { label: '功能渗透率环比', value: '+12.4%', target: '+10%', status: 'success' },
  { label: '评审一次通过率', value: '84.3%', target: '85%', status: 'warning' },
  { label: '线上缺陷密度', value: '0.05', target: '<0.1', status: 'success' },
];
