import { GoogleGenAI } from "@google/genai";
import { Employee } from "../types";

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

export const analyzeTeamPerformance = async (employees: Employee[], deptStats: any[]) => {
  if (!apiKey) {
    return "未检测到 API Key，请检查配置。";
  }

  const prompt = `
    你是一个数字产品部门的AI绩效分析师。
    请分析以下来自 "Bizflow" 业务系统的 JSON 数据。
    
    注意：不同的业务线（如核心电商、用户增长、商业化）因为业务属性不同，其“业务结果达成率”的基准水平可能不一，请在分析时考虑这一点。
    
    部门统计数据:
    ${JSON.stringify(deptStats)}

    员工数据:
    ${JSON.stringify(employees)}

    请提供一份简洁的 Markdown 格式的执行摘要（使用中文），包含以下部分：
    1. **业绩亮点** (Performance Highlights)：识别高产出员工，并关注他们的业务线背景。
    2. **风险领域** (Risk Areas)：哪些指标（特别是评审通过率、交付及时率）或员工表现落后？
    3. **业务线洞察** (Business Line Insights)：对比不同业务线的表现差异，是否存在系统性瓶颈？
    4. **改进建议** (Recommendations)：基于趋势提出 2-3 条可落地的部门效率提升建议。
    
    保持语气专业且具有建设性。
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    return "生成分析失败，请稍后再试。";
  }
};