
export type Role = 'Manager' | 'Product Manager' | 'UX Designer';

export interface Employee {
  id: string;
  name: string;
  role: Role;
  subTeam: string; // e.g., "交易中台组", "用户增长组"
  businessLine?: string; 
  level: string; 
  avatar: string;
  metrics: {
    primary: number; 
    secondary: number; 
    trend: 'up' | 'down' | 'stable';
    trendValue: number;
  };
  details: {
    [key: string]: string | number;
  };
}

export interface Project {
  id: string;
  name: string;
  grade: 'S' | 'A' | 'B';
  owner: string;
  subTeam: string;
  status: 'In Progress' | 'Completed' | 'Delayed';
  progress: number;
  businessValue: number; // 1-100 score
  weeklyFocus?: string; // New: User defined weekly goal for this project
}

// New: For Data Persistence (Performance History)
export interface PerformanceSnapshot {
  id: string;
  employeeId: string; // Link to specific employee
  period: string; // e.g., "2024 Q1", "2023 Annual"
  roleSnapshot: string; // Role at that time
  teamSnapshot: string; // Team at that time
  finalGrade: string; // S/A/B/C
  metrics: {
    label: string;
    value: string | number;
    target: string | number;
    achievementRate: number;
  }[];
  keyProjects: {
    name: string;
    grade: string;
    result: string;
  }[];
}

export interface FeatureMetric {
  name: string;
  team: string;
  usageTrend: { month: string; value: number }[];
  wowGrowth: number; // Week over Week
  momGrowth: number; // Month over Month
}

export interface ReviewStat {
  team: string;
  month: string;
  passRate: number; // %
  avgRounds: number; // Average review rounds
}

export interface PhaseStep {
  title: string;
  timeframe?: string; // Optional now
  progress: number; // 0-100
  status: 'completed' | 'in-progress' | 'pending';
  items: string[];
  owner?: string; // Optional now
}
