
import React, { useState } from 'react';
import { MOCK_EMPLOYEES, MOCK_PERFORMANCE_HISTORY } from '../constants';
import { Search, User, FileText, ChevronRight, Filter, Award, BarChart3, Lock, FolderOpen } from 'lucide-react';

const DeptPerformanceArchives: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedEmployeeId, setSelectedEmployeeId] = useState<string | null>(null);

  // Filter employees based on search
  const filteredEmployees = MOCK_EMPLOYEES.filter(emp => 
    emp.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    emp.subTeam.toLowerCase().includes(searchTerm.toLowerCase()) ||
    emp.role.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const selectedEmployee = MOCK_EMPLOYEES.find(e => e.id === selectedEmployeeId);
  const employeeSnapshots = MOCK_PERFORMANCE_HISTORY.filter(s => s.employeeId === selectedEmployeeId);

  return (
    <div className="flex h-[calc(100vh-140px)] gap-6 animate-fade-in">
      {/* Left Sidebar: Employee List */}
      <div className="w-1/3 bg-white rounded-xl border border-slate-200 shadow-sm flex flex-col overflow-hidden">
         <div className="p-4 border-b border-slate-100">
            <h3 className="font-bold text-slate-800 mb-3">人员列表</h3>
            <div className="relative">
               <Search size={16} className="absolute left-3 top-2.5 text-slate-400" />
               <input 
                  type="text" 
                  placeholder="搜索姓名、小组..." 
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-9 pr-4 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-500"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
               />
            </div>
         </div>
         <div className="flex-1 overflow-y-auto p-2 space-y-1">
            {filteredEmployees.map(emp => (
               <div 
                  key={emp.id}
                  onClick={() => setSelectedEmployeeId(emp.id)}
                  className={`p-3 rounded-lg flex items-center gap-3 cursor-pointer transition-colors ${
                     selectedEmployeeId === emp.id ? 'bg-blue-50 border border-blue-200' : 'hover:bg-slate-50 border border-transparent'
                  }`}
               >
                  <img src={emp.avatar} alt={emp.name} className="w-10 h-10 rounded-full object-cover border border-slate-100" />
                  <div className="flex-1 min-w-0">
                     <div className="font-bold text-sm text-slate-800 flex justify-between">
                        {emp.name}
                        {selectedEmployeeId === emp.id && <ChevronRight size={16} className="text-blue-500"/>}
                     </div>
                     <div className="text-xs text-slate-500 truncate">{emp.subTeam} • {emp.role}</div>
                  </div>
               </div>
            ))}
            {filteredEmployees.length === 0 && (
               <div className="p-8 text-center text-slate-400 text-sm">未找到匹配员工</div>
            )}
         </div>
      </div>

      {/* Right Content: Performance History */}
      <div className="flex-1 bg-white rounded-xl border border-slate-200 shadow-sm flex flex-col overflow-hidden">
         {selectedEmployee ? (
            <div className="flex flex-col h-full">
               {/* Employee Header */}
               <div className="p-6 border-b border-slate-100 bg-slate-50/50 flex justify-between items-center">
                  <div className="flex items-center gap-4">
                     <img src={selectedEmployee.avatar} alt={selectedEmployee.name} className="w-16 h-16 rounded-full border-4 border-white shadow-sm" />
                     <div>
                        <h2 className="text-2xl font-bold text-slate-800">{selectedEmployee.name}</h2>
                        <div className="flex items-center gap-2 text-slate-500 text-sm mt-1">
                           <span className="bg-white px-2 py-0.5 rounded border border-slate-200">{selectedEmployee.level}</span>
                           <span>{selectedEmployee.role}</span>
                           <span>•</span>
                           <span>{selectedEmployee.subTeam}</span>
                        </div>
                     </div>
                  </div>
                  <div className="text-right">
                     <button className="bg-white border border-slate-300 text-slate-700 px-4 py-2 rounded-lg text-sm font-medium hover:bg-slate-50 shadow-sm flex items-center gap-2">
                        <FolderOpen size={16} /> 导出完整档案
                     </button>
                  </div>
               </div>

               {/* Snapshots List */}
               <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-50">
                  <div className="flex items-center gap-2 text-sm text-slate-500 mb-2">
                     <Lock size={14} />
                     <span>以下数据已归档锁定 (共 {employeeSnapshots.length} 条记录)</span>
                  </div>

                  {employeeSnapshots.length > 0 ? employeeSnapshots.map((snap) => (
                     <div key={snap.id} className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
                        <div className="bg-slate-50/80 px-6 py-4 border-b border-slate-200 flex justify-between items-center">
                           <div>
                              <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                                 {snap.period} 绩效快照
                                 <span className="text-xs font-normal text-slate-400 bg-white border border-slate-200 px-2 py-0.5 rounded-full">ID: {snap.id}</span>
                              </h3>
                              <div className="text-xs text-slate-500 mt-0.5">
                                 当时岗位: {snap.roleSnapshot} • 所属团队: {snap.teamSnapshot}
                              </div>
                           </div>
                           <div className="flex items-center gap-3">
                              <div className="text-right">
                                 <div className="text-xs text-slate-400">综合评级</div>
                                 <div className={`text-xl font-bold ${snap.finalGrade === 'S' ? 'text-purple-600' : 'text-blue-600'}`}>
                                    {snap.finalGrade}
                                 </div>
                              </div>
                           </div>
                        </div>
                        
                        <div className="p-6 grid grid-cols-1 lg:grid-cols-2 gap-8">
                           <div>
                              <h4 className="text-sm font-bold text-slate-700 mb-3 flex items-center gap-2">
                                 <BarChart3 size={16} className="text-slate-400"/> 核心指标达成情况
                              </h4>
                              <div className="space-y-3">
                                 {snap.metrics.map((m, i) => (
                                    <div key={i} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-100">
                                       <span className="text-sm text-slate-600">{m.label}</span>
                                       <div className="text-right">
                                          <div className="text-sm font-bold text-slate-800">{m.value}</div>
                                          <div className={`text-xs ${m.achievementRate >= 100 ? 'text-emerald-600' : 'text-amber-500'}`}>
                                             达成率 {m.achievementRate}%
                                          </div>
                                       </div>
                                    </div>
                                 ))}
                              </div>
                           </div>

                           <div>
                              <h4 className="text-sm font-bold text-slate-700 mb-3 flex items-center gap-2">
                                 <Award size={16} className="text-slate-400"/> 周期内关键产出
                              </h4>
                              <div className="space-y-2">
                                 {snap.keyProjects.map((p, i) => (
                                    <div key={i} className="border-l-2 border-slate-300 pl-3 py-1">
                                       <div className="text-sm font-medium text-slate-800 flex items-center gap-2">
                                          {p.name}
                                          <span className="text-[10px] px-1.5 rounded bg-slate-100 text-slate-600 border border-slate-200">{p.grade}级</span>
                                       </div>
                                       <div className="text-xs text-slate-500 mt-1">结果: {p.result}</div>
                                    </div>
                                 ))}
                              </div>
                           </div>
                        </div>
                     </div>
                  )) : (
                     <div className="flex flex-col items-center justify-center h-64 text-slate-400">
                        <FileText size={48} className="mb-4 text-slate-300" />
                        <p>该员工暂无归档的绩效快照。</p>
                     </div>
                  )}
               </div>
            </div>
         ) : (
            <div className="flex flex-col items-center justify-center h-full text-slate-400 bg-slate-50">
               <User size={64} className="mb-4 text-slate-300" />
               <p className="text-lg font-medium text-slate-500">请从左侧列表选择一名员工</p>
               <p className="text-sm">查看其历史绩效档案与综评记录</p>
            </div>
         )}
      </div>
    </div>
  );
};

export default DeptPerformanceArchives;
