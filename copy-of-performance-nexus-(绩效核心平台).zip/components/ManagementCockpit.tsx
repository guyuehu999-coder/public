import React, { useState } from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  ComposedChart, Line, Area, Cell, PieChart, Pie
} from 'recharts';
import { MANAGEMENT_OVERVIEW_DATA, COCKPIT_USAGE_DATA, COCKPIT_PROJECT_STATS, REVIEW_OVERVIEW_DATA } from '../constants';
import { Target, TrendingUp, TrendingDown, Layout, Rocket, Zap, Clock, AlertTriangle, CheckCircle, MousePointerClick, Sparkles, Workflow, ClipboardCheck, ArrowRight } from 'lucide-react';

type TimeRange = 'day' | 'month' | 'year';

const ManagementCockpit: React.FC = () => {
  const [timeRange, setTimeRange] = useState<TimeRange>('month');

  // Dynamic data based on time range
  const metrics = MANAGEMENT_OVERVIEW_DATA.metricsMap[timeRange];
  const trendData = MANAGEMENT_OVERVIEW_DATA.trendDataMap[timeRange];
  const aiPrediction = MANAGEMENT_OVERVIEW_DATA.aiPredictions[timeRange];

  const { userJourney, platformDetails } = COCKPIT_USAGE_DATA;
  const { overview: projectOverview, keyProjects } = COCKPIT_PROJECT_STATS;
  const reviewStats = REVIEW_OVERVIEW_DATA;

  return (
    <div className="space-y-10 animate-fade-in pb-12">
      <div className="border-b border-slate-200 pb-4 flex justify-between items-end">
         <div>
            <h2 className="text-2xl font-bold text-slate-800">管理层驾驶舱 · 2024</h2>
            <p className="text-sm text-slate-500">核心关注：业务转化、用户旅程、交付与评审效能</p>
         </div>
         <div className="flex bg-slate-100 p-1 rounded-lg">
            {(['day', 'month', 'year'] as TimeRange[]).map((range) => (
               <button
                  key={range}
                  onClick={() => setTimeRange(range)}
                  className={`px-4 py-1.5 rounded-md text-sm font-medium transition-all ${
                     timeRange === range ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'
                  }`}
               >
                  {range === 'day' ? '日' : range === 'month' ? '月' : '年'}
               </button>
            ))}
         </div>
      </div>

      {/* --- SECTION 1: 业务转化类指标概览 (Business Conversion) --- */}
      <section className="space-y-4">
        <div className="flex items-center gap-2 mb-2">
          <div className="p-2 bg-blue-100 text-blue-600 rounded-lg">
            <Target size={20} />
          </div>
          <h3 className="text-xl font-bold text-slate-800">一、业务转化类指标概览</h3>
          <span className="text-xs bg-slate-100 text-slate-500 px-2 py-1 rounded">Conversion Metrics</span>
        </div>

        {/* AI Prediction Banner */}
        <div className="bg-gradient-to-r from-violet-50 to-indigo-50 border border-indigo-100 rounded-lg p-4 flex items-start gap-3">
            <Sparkles size={18} className="text-indigo-600 mt-0.5 shrink-0" />
            <div>
               <div className="text-sm font-bold text-indigo-800">AI 趋势预测评估</div>
               <p className="text-sm text-indigo-600 mt-1 leading-relaxed">
                  {aiPrediction}
               </p>
            </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Key Metrics Cards */}
          <div className="lg:col-span-1 grid grid-cols-1 gap-4">
            {metrics.map((metric, index) => (
              <div key={index} className="bg-white p-5 rounded-xl shadow-sm border border-slate-200 flex justify-between items-center transition-all hover:shadow-md">
                <div>
                  <div className="text-sm text-slate-500">{metric.name}</div>
                  <div className="text-2xl font-bold text-slate-800 mt-1">{metric.value}</div>
                  <div className="text-xs text-slate-400 mt-1">{metric.desc}</div>
                </div>
                <div className="flex flex-col items-end">
                   <div className={`flex items-center text-sm font-bold ${
                     metric.change === '0.0%' ? 'text-slate-400' : 'text-emerald-600'
                   }`}>
                     {metric.change !== '0.0%' && <TrendingUp size={14} className="mr-1" />}
                     {metric.change}
                   </div>
                   <div className="text-xs text-slate-400 mt-1">环比</div>
                </div>
              </div>
            ))}
          </div>

          {/* Trend Chart */}
          <div className="lg:col-span-2 bg-white p-6 rounded-xl shadow-sm border border-slate-200">
            <div className="flex justify-between items-center mb-6">
              <h4 className="font-bold text-slate-700">关键指标趋势 ({timeRange === 'day' ? '24小时' : timeRange === 'month' ? '30天' : '12个月'})</h4>
              <div className="flex gap-4 text-xs">
                 <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-blue-500"></span> 注册数 (左轴)</span>
                 <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-orange-500"></span> 转化率% (右轴)</span>
              </div>
            </div>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <ComposedChart data={trendData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9"/>
                  <XAxis dataKey="label" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} interval={timeRange === 'day' ? 3 : 0} />
                  <YAxis yAxisId="left" orientation="left" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
                  <YAxis yAxisId="right" orientation="right" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} unit="%" domain={[0, 'auto']}/>
                  <Tooltip contentStyle={{borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'}}/>
                  <Area yAxisId="left" type="monotone" dataKey="注册数" stroke="#3b82f6" fillOpacity={0.1} fill="#3b82f6" strokeWidth={2}/>
                  <Line yAxisId="right" type="monotone" dataKey="转化率" stroke="#f97316" strokeWidth={2} dot={false} />
                </ComposedChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </section>

      {/* --- SECTION 2: 核心功能使用量 (User Journey View) --- */}
      <section className="space-y-4 border-t border-slate-200 pt-8">
        <div className="flex items-center gap-2 mb-2">
          <div className="p-2 bg-purple-100 text-purple-600 rounded-lg">
            <MousePointerClick size={20} />
          </div>
          <h3 className="text-xl font-bold text-slate-800">二、核心功能使用量 (用户旅程视角)</h3>
          <span className="text-xs bg-slate-100 text-slate-500 px-2 py-1 rounded">Journey Map & Feature Adoption</span>
        </div>

        {/* User Journey Flow Visualization */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 mb-6">
           <div className="flex justify-between items-center mb-6">
              <h4 className="font-bold text-slate-700 flex items-center gap-2">
                 <Workflow size={18} className="text-slate-500" />
                 平台网站用户旅程转化漏斗
              </h4>
           </div>
           
           <div className="grid grid-cols-1 md:grid-cols-4 gap-4 relative">
              {userJourney.map((step, idx) => (
                 <div key={idx} className="relative z-10">
                    <div className={`p-4 rounded-lg border flex flex-col items-center text-center h-full ${
                       idx === 0 ? 'bg-blue-50 border-blue-200' :
                       idx === 1 ? 'bg-indigo-50 border-indigo-200' :
                       idx === 2 ? 'bg-purple-50 border-purple-200' :
                       'bg-emerald-50 border-emerald-200'
                    }`}>
                       <div className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">{step.stage}</div>
                       <div className="text-2xl font-bold text-slate-800 mb-1">{step.count}</div>
                       <div className="mt-auto pt-2 border-t border-slate-200/50 w-full flex justify-between items-center px-2 text-xs">
                          <span className="text-slate-500">转化: {step.conversion}</span>
                          <span className={`${step.trend === 'up' ? 'text-emerald-600' : 'text-red-500'}`}>
                             {step.trend === 'up' ? '↑' : '↓'}
                          </span>
                       </div>
                    </div>
                    {/* Arrow Connector for Desktop */}
                    {idx < userJourney.length - 1 && (
                       <div className="hidden md:block absolute top-1/2 -right-3 transform -translate-y-1/2 z-20 text-slate-300">
                          <ArrowRight size={24} />
                       </div>
                    )}
                 </div>
              ))}
           </div>
        </div>

        {/* 4 Platforms Detailed Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
           {platformDetails.map((platform, idx) => (
              <div key={idx} className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden flex flex-col">
                 <div className={`px-4 py-3 border-b border-slate-100 font-bold text-sm flex items-center gap-2 ${
                    platform.color === 'blue' ? 'bg-blue-50 text-blue-800' : 
                    platform.color === 'purple' ? 'bg-purple-50 text-purple-800' :
                    platform.color === 'emerald' ? 'bg-emerald-50 text-emerald-800' : 'bg-orange-50 text-orange-800'
                 }`}>
                    <Layout size={14} />
                    {platform.name}
                 </div>
                 <div className="p-4 space-y-3 flex-1">
                    {platform.features.map((feat, fIdx) => (
                       <div key={fIdx} className="flex items-center justify-between p-2 rounded hover:bg-slate-50 transition-colors">
                          <div className="flex flex-col">
                             <span className="text-xs font-medium text-slate-700">{feat.name}</span>
                             <span className="text-[10px] text-slate-400">PV: {feat.pv}</span>
                          </div>
                          <div className="text-right">
                             <span className="text-sm font-bold text-slate-800">{feat.clickRate}</span>
                             <div className="w-12 h-1 bg-slate-100 rounded-full mt-1">
                                <div className={`h-1 rounded-full ${
                                    platform.color === 'blue' ? 'bg-blue-500' : 
                                    platform.color === 'purple' ? 'bg-purple-500' :
                                    platform.color === 'emerald' ? 'bg-emerald-500' : 'bg-orange-500'
                                }`} style={{width: feat.clickRate}}></div>
                             </div>
                          </div>
                       </div>
                    ))}
                 </div>
              </div>
           ))}
        </div>
      </section>

      {/* --- SECTION 3: 核心项目交付 & 评审效能 (Projects & Reviews) --- */}
      <section className="space-y-4 border-t border-slate-200 pt-8">
        <div className="flex items-center gap-2 mb-2">
          <div className="p-2 bg-emerald-100 text-emerald-600 rounded-lg">
            <Rocket size={20} />
          </div>
          <h3 className="text-xl font-bold text-slate-800">三、核心项目交付与评审</h3>
          <span className="text-xs bg-slate-100 text-slate-500 px-2 py-1 rounded">Delivery & Quality</span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
           {/* Left: Project Stats */}
           <div className="lg:col-span-2 bg-white rounded-xl shadow-sm border border-slate-200 p-6">
              {/* Stats Row */}
              <div className="grid grid-cols-4 gap-4 mb-6 pb-6 border-b border-slate-100">
                 <div>
                    <div className="text-xs text-slate-500 mb-1">S级项目完成度</div>
                    <div className="text-xl font-bold text-slate-800">{projectOverview.sClassDone}/{projectOverview.sClassCount}</div>
                 </div>
                 <div>
                    <div className="text-xs text-slate-500 mb-1">整体交付率</div>
                    <div className="text-xl font-bold text-emerald-600">{projectOverview.onTimeRate}</div>
                 </div>
                 <div>
                    <div className="text-xs text-slate-500 mb-1">延期项目</div>
                    <div className="text-xl font-bold text-amber-500">{projectOverview.delayCount}</div>
                 </div>
                 <div>
                    <div className="text-xs text-slate-500 mb-1">本月投产</div>
                    <div className="text-xl font-bold text-slate-800">5</div>
                 </div>
              </div>
              
              <h4 className="font-bold text-slate-700 mb-4 flex items-center gap-2">
                 <Zap size={16} className="text-amber-500"/> 重点关注项目
              </h4>
              <div className="overflow-x-auto">
                 <table className="w-full text-sm text-left">
                    <thead className="bg-slate-50 text-xs text-slate-500 uppercase">
                       <tr>
                          <th className="px-3 py-2 rounded-l-lg">项目</th>
                          <th className="px-3 py-2">等级</th>
                          <th className="px-3 py-2">进度</th>
                          <th className="px-3 py-2 text-right rounded-r-lg">状态</th>
                       </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                       {keyProjects.slice(0, 4).map((proj, idx) => (
                          <tr key={idx} className="hover:bg-slate-50">
                             <td className="px-3 py-2 font-medium text-slate-800">{proj.name}</td>
                             <td className="px-3 py-2"><span className={`px-1.5 py-0.5 rounded text-xs font-bold ${proj.grade === 'S' ? 'bg-red-100 text-red-700' : 'bg-blue-100 text-blue-700'}`}>{proj.grade}</span></td>
                             <td className="px-3 py-2">
                                <div className="w-16 bg-slate-200 h-1.5 rounded-full">
                                   <div className="bg-blue-500 h-1.5 rounded-full" style={{width: `${proj.progress}%`}}></div>
                                </div>
                             </td>
                             <td className="px-3 py-2 text-right">
                                <span className={`text-xs font-medium ${proj.status === '延期' ? 'text-red-500' : 'text-emerald-600'}`}>{proj.status}</span>
                             </td>
                          </tr>
                       ))}
                    </tbody>
                 </table>
              </div>
           </div>

           {/* Right: Review Metrics (New) */}
           <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
              <div className="flex items-center justify-between mb-6">
                 <h4 className="font-bold text-slate-700 flex items-center gap-2">
                    <ClipboardCheck size={18} className="text-slate-500"/> 项目评审效能
                 </h4>
                 <span className="text-xs bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded">
                    环比 {reviewStats.trend === 'up' ? '↑' : '↓'}
                 </span>
              </div>
              
              <div className="space-y-6">
                 <div className="flex items-center justify-between">
                    <div className="text-sm text-slate-500">一次评审通过率</div>
                    <div className="text-2xl font-bold text-slate-800">{reviewStats.passRate}%</div>
                 </div>
                 
                 <div className="w-full bg-slate-100 rounded-full h-2">
                    <div className="bg-blue-600 h-2 rounded-full" style={{width: `${reviewStats.passRate}%`}}></div>
                 </div>

                 <div className="grid grid-cols-2 gap-4 pt-2">
                    {reviewStats.stats.map((stat, i) => (
                       <div key={i} className="bg-slate-50 p-3 rounded-lg border border-slate-100">
                          <div className="text-xs text-slate-500 mb-1">{stat.label}</div>
                          <div className="font-bold text-slate-800">
                             {stat.value} <span className="text-xs font-normal text-slate-400">{stat.unit}</span>
                          </div>
                       </div>
                    ))}
                    <div className="bg-slate-50 p-3 rounded-lg border border-slate-100">
                       <div className="text-xs text-slate-500 mb-1">平均耗时</div>
                       <div className="font-bold text-slate-800">
                          {reviewStats.avgDuration} <span className="text-xs font-normal text-slate-400">天</span>
                       </div>
                    </div>
                 </div>
              </div>
           </div>
        </div>
      </section>
    </div>
  );
};

export default ManagementCockpit;