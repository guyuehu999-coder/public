
import React, { useState } from 'react';
import { MOCK_EMPLOYEES, MOCK_PROJECTS } from '../constants';
import { Employee } from '../types';
import { Trophy, TrendingUp, TrendingDown, Minus, Info, Zap, Crown, Palette, Layers, Star } from 'lucide-react';

type LeaderboardCategory = 'overall' | 'delivery' | 'design';

const Leaderboard: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<LeaderboardCategory>('overall');

  // Helper: Calculate Delivery Stats dynamically from MOCK_PROJECTS
  const getDeliveryStats = (employeeName: string) => {
    const empProjects = MOCK_PROJECTS.filter(p => p.owner === employeeName);
    const sCount = empProjects.filter(p => p.grade === 'S').length;
    const aCount = empProjects.filter(p => p.grade === 'A').length;
    const total = empProjects.length;
    // Weighted Score: S=5pts, A=3pts, B=1pt
    const score = (sCount * 5) + (aCount * 3) + (empProjects.filter(p => p.grade === 'B').length);
    return { sCount, aCount, total, score };
  };

  // 1. Overall Ranking (PM + UX, based on Primary Metric)
  const getOverallRankings = () => {
    return [...MOCK_EMPLOYEES].sort((a, b) => b.metrics.primary - a.metrics.primary);
  };

  // 2. Delivery Ranking (PM focused, based on Project Grades)
  const getDeliveryRankings = () => {
    return MOCK_EMPLOYEES
      .filter(e => e.role === 'Product Manager')
      .map(e => ({
        ...e,
        deliveryStats: getDeliveryStats(e.name)
      }))
      .sort((a, b) => b.deliveryStats.score - a.deliveryStats.score);
  };

  // 3. Design Ranking (UX focused, based on Design Stats)
  const getDesignRankings = () => {
    return MOCK_EMPLOYEES
      .filter(e => e.role === 'UX Designer')
      .sort((a, b) => b.metrics.secondary - a.metrics.secondary); // Secondary is "User Exp Contribution"
  };

  const renderOverallTable = () => (
    <table className="w-full text-left">
      <thead className="bg-slate-50 border-b border-slate-200">
        <tr>
          <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase w-16">排名</th>
          <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase">员工信息</th>
          <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase">所属团队</th>
          <th className="px-6 py-4 text-xs font-semibold text-blue-700 uppercase text-right bg-blue-50/30">KPI 达成率</th>
          <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase text-center">业绩趋势</th>
        </tr>
      </thead>
      <tbody className="divide-y divide-slate-100">
        {getOverallRankings().map((emp, index) => (
          <tr key={emp.id} className="hover:bg-slate-50 transition-colors">
             <td className="px-6 py-4">
                <RankBadge index={index} />
             </td>
             <td className="px-6 py-4">
               <EmployeeCell emp={emp} />
             </td>
             <td className="px-6 py-4 text-sm text-slate-600">{emp.subTeam}</td>
             <td className="px-6 py-4 text-right bg-blue-50/10">
               <div className="font-bold text-blue-700">{emp.metrics.primary}%</div>
               <div className="text-xs text-slate-400">目标: 90%</div>
             </td>
             <td className="px-6 py-4">
                <TrendIndicator type={emp.metrics.trend} />
             </td>
          </tr>
        ))}
      </tbody>
    </table>
  );

  const renderDeliveryTable = () => (
    <table className="w-full text-left">
      <thead className="bg-slate-50 border-b border-slate-200">
        <tr>
          <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase w-16">排名</th>
          <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase">产品经理</th>
          <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase">高价值项目 (S/A级)</th>
          <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase text-center">总主导数</th>
          <th className="px-6 py-4 text-xs font-semibold text-indigo-700 uppercase text-right bg-indigo-50/30">交付战力值</th>
        </tr>
      </thead>
      <tbody className="divide-y divide-slate-100">
        {getDeliveryRankings().map((item, index) => (
          <tr key={item.id} className="hover:bg-slate-50 transition-colors">
             <td className="px-6 py-4">
                <RankBadge index={index} />
             </td>
             <td className="px-6 py-4">
                <EmployeeCell emp={item} showRole={false} />
             </td>
             <td className="px-6 py-4">
                <div className="flex gap-2">
                   {item.deliveryStats.sCount > 0 && (
                      <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-bold bg-red-100 text-red-700 border border-red-200 shadow-sm">
                        S级 x{item.deliveryStats.sCount}
                      </span>
                   )}
                   {item.deliveryStats.aCount > 0 && (
                      <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-blue-100 text-blue-700 border border-blue-200">
                        A级 x{item.deliveryStats.aCount}
                      </span>
                   )}
                   {item.deliveryStats.sCount === 0 && item.deliveryStats.aCount === 0 && (
                      <span className="text-xs text-slate-400">无核心项目</span>
                   )}
                </div>
             </td>
             <td className="px-6 py-4 text-center font-medium text-slate-700">
                {item.deliveryStats.total}
             </td>
             <td className="px-6 py-4 text-right bg-indigo-50/10">
                <div className="font-bold text-indigo-700 text-lg">{item.deliveryStats.score}</div>
                <div className="text-[10px] text-slate-400">加权分</div>
             </td>
          </tr>
        ))}
      </tbody>
    </table>
  );

  const renderDesignTable = () => (
    <table className="w-full text-left">
      <thead className="bg-slate-50 border-b border-slate-200">
        <tr>
          <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase w-16">排名</th>
          <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase">设计师</th>
          <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase">设计验收通过率</th>
           <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase">体验满意度</th>
          <th className="px-6 py-4 text-xs font-semibold text-purple-700 uppercase text-right bg-purple-50/30">深度/贡献值</th>
        </tr>
      </thead>
      <tbody className="divide-y divide-slate-100">
        {getDesignRankings().map((emp, index) => (
          <tr key={emp.id} className="hover:bg-slate-50 transition-colors">
             <td className="px-6 py-4">
                <RankBadge index={index} />
             </td>
             <td className="px-6 py-4">
               <EmployeeCell emp={emp} showRole={false} />
             </td>
             <td className="px-6 py-4">
                <div className="flex items-center gap-2">
                   <div className="w-16 bg-slate-200 h-1.5 rounded-full overflow-hidden">
                      <div className="bg-emerald-500 h-1.5 rounded-full" style={{ width: emp.details['设计验收通过率'] }}></div>
                   </div>
                   <span className="text-sm font-medium text-slate-700">{emp.details['设计验收通过率']}</span>
                </div>
             </td>
             <td className="px-6 py-4">
                <div className="flex items-center gap-1 text-amber-500 text-sm font-bold">
                   <Star size={14} fill="currentColor" />
                   {emp.details['体验满意度']}
                </div>
             </td>
             <td className="px-6 py-4 text-right bg-purple-50/10">
                <div className="font-bold text-purple-700 text-lg">{emp.metrics.secondary}</div>
                <div className="text-[10px] text-slate-400">高难度课题贡献</div>
             </td>
          </tr>
        ))}
      </tbody>
    </table>
  );

  return (
    <div className="space-y-6">
      {/* Header & Tabs */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">部门业绩龙虎榜</h2>
          <p className="text-slate-500">数据来源：Bizflow 项目管理系统 & 绩效考核表</p>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="flex gap-4 border-b border-slate-200">
        <button
          onClick={() => setActiveCategory('overall')}
          className={`pb-3 px-1 text-sm font-medium transition-all flex items-center gap-2 border-b-2 ${
            activeCategory === 'overall' 
              ? 'border-blue-600 text-blue-600' 
              : 'border-transparent text-slate-500 hover:text-slate-700'
          }`}
        >
          <Trophy size={16} /> 综合业绩榜
        </button>
        <button
          onClick={() => setActiveCategory('delivery')}
          className={`pb-3 px-1 text-sm font-medium transition-all flex items-center gap-2 border-b-2 ${
            activeCategory === 'delivery' 
              ? 'border-indigo-600 text-indigo-600' 
              : 'border-transparent text-slate-500 hover:text-slate-700'
          }`}
        >
          <Zap size={16} /> 项目交付榜 (PM)
        </button>
        <button
          onClick={() => setActiveCategory('design')}
          className={`pb-3 px-1 text-sm font-medium transition-all flex items-center gap-2 border-b-2 ${
            activeCategory === 'design' 
              ? 'border-purple-600 text-purple-600' 
              : 'border-transparent text-slate-500 hover:text-slate-700'
          }`}
        >
          <Palette size={16} /> 设计卓越榜 (UX)
        </button>
      </div>

      {/* Dynamic Banner based on Tab */}
      <div className={`rounded-lg p-3 flex items-start gap-3 border ${
        activeCategory === 'overall' ? 'bg-blue-50 border-blue-100 text-blue-800' :
        activeCategory === 'delivery' ? 'bg-indigo-50 border-indigo-100 text-indigo-800' :
        'bg-purple-50 border-purple-100 text-purple-800'
      }`}>
        <Info size={18} className="mt-0.5 shrink-0 opacity-80" />
        <div>
          <div className="text-sm font-bold mb-0.5">
            {activeCategory === 'overall' && '榜单逻辑：基于 KPI 综合达成率'}
            {activeCategory === 'delivery' && '榜单逻辑：基于主导项目的数量与等级 (战力值 = S级x5 + A级x3 + B级x1)'}
            {activeCategory === 'design' && '榜单逻辑：基于设计验收质量与高难度课题贡献值'}
          </div>
          <p className="text-xs opacity-80">
             {activeCategory === 'overall' && '展示全员核心业务结果，不论职级。'}
             {activeCategory === 'delivery' && '数据实时抓取自 Bizflow 项目立项与结项表。'}
             {activeCategory === 'design' && '侧重于设计方案的落地还原度与体验深度。'}
          </p>
        </div>
      </div>

      {/* Main Table Container */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden min-h-[400px]">
        {activeCategory === 'overall' && renderOverallTable()}
        {activeCategory === 'delivery' && renderDeliveryTable()}
        {activeCategory === 'design' && renderDesignTable()}
        
        {/* Empty State Check */}
        {((activeCategory === 'delivery' && getDeliveryRankings().length === 0) || 
          (activeCategory === 'design' && getDesignRankings().length === 0)) && (
          <div className="p-12 text-center text-slate-500">该榜单暂无上榜数据。</div>
        )}
      </div>
    </div>
  );
};

// Sub-components for cleaner render code
const RankBadge = ({ index }: { index: number }) => (
  <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold shadow-sm ${
    index === 0 ? 'bg-yellow-100 text-yellow-700 ring-2 ring-yellow-50' :
    index === 1 ? 'bg-slate-200 text-slate-700 ring-2 ring-slate-100' :
    index === 2 ? 'bg-amber-100 text-amber-800 ring-2 ring-amber-50' :
    'text-slate-500 bg-slate-50'
  }`}>
    {index <= 2 ? <Crown size={14} /> : index + 1}
  </div>
);

const EmployeeCell = ({ emp, showRole = true }: { emp: Employee, showRole?: boolean }) => (
  <div className="flex items-center gap-3">
    <img src={emp.avatar} alt={emp.name} className="w-10 h-10 rounded-full object-cover border border-slate-200" />
    <div>
      <div className="font-semibold text-slate-800">{emp.name}</div>
      <div className="text-xs text-slate-500">
        {emp.level} {showRole && `• ${emp.role === 'Product Manager' ? '产品经理' : '设计师'}`}
      </div>
    </div>
  </div>
);

const TrendIndicator = ({ type }: { type: 'up' | 'down' | 'stable' }) => (
  <div className="flex justify-center">
    {type === 'up' && <TrendingUp size={18} className="text-emerald-500" />}
    {type === 'down' && <TrendingDown size={18} className="text-red-500" />}
    {type === 'stable' && <Minus size={18} className="text-slate-300" />}
  </div>
);

export default Leaderboard;
