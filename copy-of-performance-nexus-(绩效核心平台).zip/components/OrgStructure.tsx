
import React from 'react';
import { MOCK_EMPLOYEES } from '../constants';
import { Network, User, Zap, Briefcase, ChevronRight, Layers } from 'lucide-react';

const OrgStructure: React.FC = () => {
  // 1. Define the Department Header (Director)
  const director = {
    name: '王强',
    title: '产品总监 (Product Director)',
    dept: '数字产品部',
    avatar: 'W' // Fallback initial
  };

  // 2. Group Employees by SubTeam
  const teams = Array.from(new Set(MOCK_EMPLOYEES.map(e => e.subTeam)));
  
  // Helper to get employees for a team
  const getTeamMembers = (teamName: string) => MOCK_EMPLOYEES.filter(e => e.subTeam === teamName);
  
  // Helper to get business line for a team (assuming first member's line represents the team)
  const getTeamBusinessLine = (teamName: string) => {
    const member = MOCK_EMPLOYEES.find(e => e.subTeam === teamName);
    return member?.businessLine || '通用中台';
  };

  return (
    <div className="space-y-8 animate-fade-in pb-12">
      <div className="flex justify-between items-end border-b border-slate-200 pb-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">组织架构与指标关联图</h2>
          <p className="text-sm text-slate-500">可视化部门层级，查看各小组自动绑定的业务考核范围。</p>
        </div>
      </div>

      {/* Level 1: Department Head */}
      <div className="flex justify-center">
        <div className="bg-slate-800 text-white rounded-xl p-6 shadow-lg w-full max-w-md relative">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-blue-500 to-purple-500 flex items-center justify-center text-2xl font-bold shadow-inner border-2 border-white/20">
              {director.avatar}
            </div>
            <div>
              <h3 className="text-xl font-bold">{director.name}</h3>
              <div className="text-slate-300 text-sm">{director.title}</div>
              <div className="flex items-center gap-1 text-xs text-slate-400 mt-1">
                <Briefcase size={12}/> {director.dept}
              </div>
            </div>
          </div>
          {/* Connector Line Down */}
          <div className="absolute -bottom-8 left-1/2 w-0.5 h-8 bg-slate-300 transform -translate-x-1/2"></div>
        </div>
      </div>

      {/* Connector Horizontal Line */}
      <div className="relative h-8 mx-auto w-3/4">
        <div className="absolute top-0 left-0 w-full h-4 border-t-2 border-l-2 border-r-2 border-slate-300 rounded-t-xl"></div>
      </div>

      {/* Level 2: Sub-Teams Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {teams.map((team) => {
          const members = getTeamMembers(team);
          const businessLine = getTeamBusinessLine(team);
          
          return (
            <div key={team} className="flex flex-col">
              {/* Team Header Card */}
              <div className="bg-white border-t-4 border-blue-500 rounded-lg shadow-sm p-4 mb-4 relative">
                {/* Connector Top */}
                <div className="absolute -top-6 left-1/2 w-0.5 h-6 bg-slate-300 transform -translate-x-1/2"></div>
                
                <div className="flex justify-between items-start mb-2">
                  <h4 className="font-bold text-lg text-slate-800">{team}</h4>
                  <div className="bg-blue-50 text-blue-700 text-xs px-2 py-1 rounded border border-blue-100 flex items-center gap-1">
                    <Layers size={12}/> {members.length} 人
                  </div>
                </div>
                
                {/* Auto-Association Badge */}
                <div className="bg-slate-50 border border-slate-200 rounded p-2 text-xs mb-1">
                  <div className="flex items-center gap-1 text-slate-500 mb-1">
                     <Zap size={12} className="text-amber-500"/>
                     <span className="font-semibold">自动关联配置:</span>
                  </div>
                  <div className="text-slate-700 pl-4">
                    • 业务线: <span className="font-medium text-blue-600">{businessLine}</span><br/>
                    • 重点指标: <span className="text-slate-500">转化率, S级交付</span>
                  </div>
                </div>
              </div>

              {/* Members List */}
              <div className="space-y-3 flex-1 relative px-2">
                 {/* Vertical Connector Line for children */}
                 <div className="absolute top-0 bottom-4 left-1/2 w-0.5 bg-slate-200 transform -translate-x-1/2 -z-10"></div>
                 
                 {members.map((emp) => (
                   <div key={emp.id} className="bg-white p-3 rounded-lg border border-slate-200 shadow-sm flex items-center gap-3 hover:shadow-md transition-shadow relative z-0">
                      <img src={emp.avatar} alt={emp.name} className="w-10 h-10 rounded-full border border-slate-100 object-cover"/>
                      <div className="flex-1 min-w-0">
                        <div className="font-bold text-sm text-slate-800 flex items-center justify-between">
                          {emp.name}
                          <span className={`text-[10px] px-1.5 rounded ${
                             emp.level.includes('资深') ? 'bg-purple-50 text-purple-700' : 'bg-slate-100 text-slate-500'
                          }`}>
                            {emp.level}
                          </span>
                        </div>
                        <div className="text-xs text-slate-500 truncate">{emp.role}</div>
                      </div>
                   </div>
                 ))}
              </div>
            </div>
          );
        })}
      </div>
      
      {/* Legend / Info */}
      <div className="mt-8 bg-blue-50 border border-blue-100 rounded-lg p-4 flex items-start gap-3 text-sm text-blue-800">
         <Network size={20} className="mt-0.5 shrink-0" />
         <div>
            <span className="font-bold">关于自动关联机制：</span>
            <p className="mt-1 text-blue-700/80">
               系统根据员工所在的“小组 (SubTeam)”自动继承对应的业务线 KPI 配置。
               例如，“交易中台组”成员的个人工作台将自动展示“核心电商”业务线的转化率指标。
               如需调整人员归属，请联系 HRBP 在 Bizflow 主数据中更新，本图表将于次日凌晨自动同步。
            </p>
         </div>
      </div>
    </div>
  );
};

export default OrgStructure;
