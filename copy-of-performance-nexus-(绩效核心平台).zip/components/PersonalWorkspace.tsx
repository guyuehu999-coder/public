
import React, { useState } from 'react';
import { MOCK_EMPLOYEES, MOCK_PROJECTS, MOCK_PERFORMANCE_HISTORY } from '../constants';
import { User, Target, BarChart3, Award, AlertTriangle, CheckSquare, Clock, ArrowUpRight, TrendingUp, CheckCircle, MousePointerClick, Zap, History, FileText, Settings, PenLine, Lock } from 'lucide-react';

const PersonalWorkspace: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'history'>('dashboard');
  
  // Simulate logged-in user (PM001 - Sarah Chen)
  const me = MOCK_EMPLOYEES[0];
  const myProjects = MOCK_PROJECTS.filter(p => p.owner === me.name);
  
  // Derived Risks (Simulation)
  const risks = myProjects.filter(p => p.status === 'Delayed');

  // Simulated To-Do List
  const todos = [
    { id: 1, text: '审批 "收银台UI改版" 的交互设计稿', due: '今天 14:00', type: 'urgent' },
    { id: 2, text: '更新 Q3 商业化项目里程碑状态', due: '明天 10:00', type: 'normal' },
    { id: 3, text: '准备 "双11大促" 核心链路压力测试报告', due: '本周五', type: 'normal' },
  ];

  return (
    <div className="space-y-8 animate-fade-in pb-10">
       {/* Header & Profile */}
       <div className="flex items-center justify-between border-b border-slate-200 pb-4">
          <div className="flex items-center gap-4">
             <img src={me.avatar} alt={me.name} className="w-16 h-16 rounded-full border-4 border-white shadow-sm"/>
             <div>
                <h2 className="text-2xl font-bold text-slate-800">早安，{me.name}</h2>
                <div className="flex items-center gap-3 text-slate-500">
                   <span className="bg-slate-100 px-2 py-0.5 rounded text-xs font-medium border border-slate-200">{me.role}</span>
                   <span className="text-sm flex items-center gap-1">
                      <Zap size={12} className="text-blue-500"/> 智能关联: {me.subTeam}
                   </span>
                </div>
             </div>
          </div>
          <div className="flex items-center gap-4">
              <div className="flex bg-slate-100 p-1 rounded-lg">
                <button 
                   onClick={() => setActiveTab('dashboard')}
                   className={`px-4 py-1.5 rounded-md text-sm font-medium transition-all flex items-center gap-2 ${activeTab === 'dashboard' ? 'bg-white shadow-sm text-blue-600' : 'text-slate-500'}`}
                >
                   <Target size={14}/> 本季工作台
                </button>
                <button 
                   onClick={() => setActiveTab('history')}
                   className={`px-4 py-1.5 rounded-md text-sm font-medium transition-all flex items-center gap-2 ${activeTab === 'history' ? 'bg-white shadow-sm text-purple-600' : 'text-slate-500'}`}
                >
                   <History size={14}/> 绩效档案 (History)
                </button>
              </div>
          </div>
       </div>

       {/* TAB 1: DASHBOARD (EDITABLE) */}
       {activeTab === 'dashboard' && (
       <>
         {/* Config Banner */}
         <div className="bg-blue-50 border border-blue-100 rounded-lg p-3 flex justify-between items-center text-sm text-blue-800">
            <div className="flex items-center gap-2">
               <Settings size={16} />
               <span>当前视图已根据您的岗位 <strong>{me.role}</strong> 和 业务线 <strong>{me.businessLine}</strong> 自动配置。</span>
            </div>
            <button className="text-blue-600 hover:text-blue-800 font-medium underline flex items-center gap-1">
               <PenLine size={14} /> 自定义指标视图
            </button>
         </div>

         {/* SECTION 1: 核心结果指标 (KPIs) */}
         <section>
            <div className="flex items-center gap-2 mb-4">
               <div className="p-1.5 bg-blue-100 text-blue-600 rounded">
                  <Target size={18} />
               </div>
               <h3 className="font-bold text-lg text-slate-800">一、核心结果指标 (KPIs)</h3>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
               {/* Card 1: Primary Metric */}
               <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl p-5 text-white shadow-md relative overflow-hidden">
                  <div className="relative z-10">
                     <div className="text-blue-100 text-sm font-medium mb-1">业务结果达成率</div>
                     <div className="text-3xl font-bold mb-2">{me.metrics.primary}%</div>
                     <div className="flex items-center gap-1 text-xs text-blue-100 bg-white/20 inline-flex px-2 py-1 rounded">
                        <TrendingUp size={12} />
                        <span>目标 90%</span>
                     </div>
                  </div>
                  <div className="absolute right-0 bottom-0 opacity-10">
                     <Target size={100} />
                  </div>
               </div>

               {/* Card 2: Conversion Metric */}
               <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm flex flex-col justify-between">
                  <div>
                     <div className="flex items-center gap-2 mb-1">
                        <TrendingUp size={16} className="text-emerald-500"/>
                        <div className="text-slate-500 text-sm font-medium">核心业务转化</div>
                     </div>
                     <div className="text-2xl font-bold text-slate-800">{me.details['核心转化率']}</div>
                     <div className="text-xs text-slate-400 mt-1">智能关联: {me.subTeam}</div>
                  </div>
                  <div className="w-full bg-slate-100 h-1.5 rounded-full mt-3">
                     <div className="bg-emerald-500 h-1.5 rounded-full" style={{width: '92%'}}></div>
                  </div>
               </div>

               {/* Card 3: Feature Usage */}
               <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm flex flex-col justify-between">
                  <div>
                     <div className="flex items-center gap-2 mb-1">
                        <MousePointerClick size={16} className="text-indigo-500"/>
                        <div className="text-slate-500 text-sm font-medium">功能使用深度</div>
                     </div>
                     <div className="text-2xl font-bold text-slate-800">{me.details['功能访问量']}</div>
                     <div className="text-xs text-slate-400 mt-1">PV/表单提交量</div>
                  </div>
                   <div className="w-full bg-slate-100 h-1.5 rounded-full mt-3">
                     <div className="bg-indigo-500 h-1.5 rounded-full" style={{width: '85%'}}></div>
                  </div>
               </div>

               {/* Card 4: S-Class Delivery */}
               <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm flex flex-col justify-between">
                  <div>
                     <div className="flex items-center gap-2 mb-1">
                        <Award size={16} className="text-amber-500"/>
                        <div className="text-slate-500 text-sm font-medium">S级项目交付</div>
                     </div>
                     <div className="text-2xl font-bold text-slate-800">{me.details['S级项目交付']}</div>
                     <div className="text-xs text-slate-400 mt-1">核心项目验收通过率</div>
                  </div>
                  <div className="flex items-center gap-2 mt-2">
                     <span className="text-xs text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded font-medium">无延期</span>
                  </div>
               </div>
            </div>
         </section>

         {/* SECTION 2: 高价值项目 (Editable) */}
         <section>
            <div className="flex items-center gap-2 mb-4">
               <div className="p-1.5 bg-indigo-100 text-indigo-600 rounded">
                  <Zap size={18} />
               </div>
               <h3 className="font-bold text-lg text-slate-800">二、重点项目进度 (可备注周目标)</h3>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
               <div className="grid grid-cols-1 divide-y divide-slate-100">
                  {myProjects.length > 0 ? myProjects.map((p, idx) => (
                     <div key={p.id} className="p-5 flex flex-col md:flex-row md:items-start justify-between gap-6 hover:bg-slate-50 transition-colors">
                        {/* Left: Project Info */}
                        <div className="flex items-start gap-4 flex-1">
                           <div className={`w-10 h-10 rounded-lg flex-shrink-0 flex items-center justify-center font-bold text-lg mt-1 ${
                              p.grade === 'S' ? 'bg-red-50 text-red-600 border border-red-100 shadow-sm' : 'bg-blue-50 text-blue-600 border border-blue-100'
                           }`}>
                              {p.grade}
                           </div>
                           <div className="flex-1">
                              <div className="font-bold text-slate-800 text-lg flex items-center gap-2">
                                 {p.name}
                                 {p.status === 'Delayed' && <span className="text-xs bg-red-100 text-red-600 px-2 py-0.5 rounded-full">已延期</span>}
                              </div>
                              <div className="text-sm text-slate-500 mt-1 flex items-center gap-3">
                                 <span>业务价值分: {p.businessValue}</span>
                                 <span className="w-1 h-1 bg-slate-300 rounded-full"></span>
                                 <span className="text-blue-600 font-medium">{p.progress}%</span>
                              </div>
                              
                              {/* Editable Weekly Focus Area */}
                              <div className="mt-3 bg-yellow-50 border border-yellow-100 rounded-md p-2 flex gap-2 w-full max-w-xl group relative">
                                  <FileText size={14} className="text-yellow-600 mt-0.5 shrink-0" />
                                  <div className="text-sm text-slate-700 w-full">
                                    <span className="font-bold text-yellow-700 text-xs uppercase tracking-wide mr-2">本周重点:</span>
                                    {p.weeklyFocus || <span className="text-slate-400 italic">点击添加本周关注点...</span>}
                                  </div>
                                  <div className="absolute top-1 right-1 opacity-0 group-hover:opacity-100">
                                      <PenLine size={12} className="text-slate-400 cursor-pointer"/>
                                  </div>
                              </div>
                           </div>
                        </div>
                        
                        {/* Right: Status */}
                        <div className="flex items-center gap-6 min-w-[120px]">
                           <button className="text-slate-400 hover:text-blue-600 flex items-center gap-1 text-xs">
                              <ArrowUpRight size={14} /> 详情
                           </button>
                        </div>
                     </div>
                  )) : (
                     <div className="p-8 text-center text-slate-400">当前无重点跟进项目</div>
                  )}
               </div>
            </div>
         </section>

         {/* SECTION 3: 风险预警 */}
         <section className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 bg-white border border-slate-200 rounded-xl shadow-sm p-6">
               <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                     <AlertTriangle size={18} className="text-amber-500" />
                     <h3 className="font-bold text-lg text-slate-800">风险与异常预警</h3>
                  </div>
                  <span className="text-xs bg-amber-50 text-amber-700 px-2 py-1 rounded-full font-medium">需要关注 {risks.length} 项</span>
               </div>
               <div className="space-y-3">
                  {risks.length > 0 && risks.map(p => (
                     <div key={p.id} className="bg-red-50 border border-red-100 rounded-lg p-4 flex items-start gap-3">
                        <AlertTriangle size={18} className="text-red-500 mt-0.5 shrink-0" />
                        <div>
                           <div className="text-sm font-bold text-red-800">项目延期预警: {p.name}</div>
                           <p className="text-xs text-red-600 mt-1">当前进度 {p.progress}%，落后于计划里程碑。</p>
                        </div>
                     </div>
                  ))}
                  {risks.length === 0 && <div className="text-sm text-slate-500">暂无重大风险。</div>}
               </div>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl shadow-sm p-6">
               <div className="flex items-center gap-2 mb-4">
                  <CheckSquare size={18} className="text-slate-600" />
                  <h3 className="font-bold text-lg text-slate-800">待办事项</h3>
               </div>
               <div className="space-y-2">
                  {todos.map(todo => (
                     <div key={todo.id} className="flex items-start gap-3 p-3 hover:bg-slate-50 rounded-lg border border-transparent hover:border-slate-100 transition-all">
                        <div className={`w-4 h-4 mt-0.5 rounded border flex-shrink-0 ${
                           todo.type === 'urgent' ? 'border-red-400 bg-red-50' : 'border-slate-300'
                        }`}></div>
                        <div className="text-sm text-slate-700">{todo.text}</div>
                     </div>
                  ))}
               </div>
            </div>
         </section>
       </>
       )}

       {/* TAB 2: HISTORY (READ ONLY) */}
       {activeTab === 'history' && (
         <div className="space-y-6">
            <div className="bg-purple-50 border border-purple-100 rounded-lg p-4 flex items-start gap-3">
               <Lock size={18} className="text-purple-600 mt-0.5 shrink-0" />
               <div>
                  <div className="text-sm font-bold text-purple-800">数据快照存档说明</div>
                  <p className="text-xs text-purple-600 mt-1 leading-relaxed">
                     本页面展示已归档的绩效周期数据。所有数据均从 Bizflow 系统定期同步并锁定，
                     不会因您的组织架构调整、项目变更或指标配置修改而丢失。此数据将作为年度绩效评估的直接依据。
                  </p>
               </div>
            </div>

            {MOCK_PERFORMANCE_HISTORY.map((snap) => (
               <div key={snap.id} className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
                  <div className="bg-slate-50 px-6 py-4 border-b border-slate-200 flex justify-between items-center">
                     <div>
                        <h3 className="text-lg font-bold text-slate-800">{snap.period} 绩效快照</h3>
                        <div className="text-xs text-slate-500 mt-0.5">
                           当时岗位: {snap.roleSnapshot} • 所属团队: {snap.teamSnapshot}
                        </div>
                     </div>
                     <div className="flex items-center gap-2">
                        <span className="text-sm text-slate-500">综合评级:</span>
                        <span className={`px-3 py-1 rounded-lg font-bold text-white ${
                           snap.finalGrade === 'S' ? 'bg-purple-600' : 'bg-blue-600'
                        }`}>
                           {snap.finalGrade}
                        </span>
                     </div>
                  </div>
                  
                  <div className="p-6 grid grid-cols-1 lg:grid-cols-2 gap-8">
                     <div>
                        <h4 className="text-sm font-bold text-slate-700 mb-3 flex items-center gap-2">
                           <BarChart3 size={16} className="text-slate-400"/> 核心指标达成情况
                        </h4>
                        <div className="space-y-3">
                           {snap.metrics.map((m, i) => (
                              <div key={i} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                                 <span className="text-sm text-slate-600">{m.label}</span>
                                 <div className="text-right">
                                    <div className="text-sm font-bold text-slate-800">{m.value}</div>
                                    <div className={`text-xs ${m.achievementRate >= 100 ? 'text-emerald-600' : 'text-amber-500'}`}>
                                       达成率 {m.achievementRate}%
                                    </div>
                                 </div>
                              </div>
                           ))}
                        </div>
                     </div>

                     <div>
                        <h4 className="text-sm font-bold text-slate-700 mb-3 flex items-center gap-2">
                           <Award size={16} className="text-slate-400"/> 周期内关键产出
                        </h4>
                        <div className="space-y-2">
                           {snap.keyProjects.map((p, i) => (
                              <div key={i} className="border-l-2 border-slate-300 pl-3 py-1">
                                 <div className="text-sm font-medium text-slate-800 flex items-center gap-2">
                                    {p.name}
                                    <span className="text-[10px] px-1.5 rounded bg-slate-100 text-slate-600 border border-slate-200">{p.grade}级</span>
                                 </div>
                                 <div className="text-xs text-slate-500 mt-1">结果: {p.result}</div>
                              </div>
                           ))}
                        </div>
                     </div>
                  </div>
               </div>
            ))}
         </div>
       )}
    </div>
  );
};

export default PersonalWorkspace;
