import React, { useState } from 'react';
import { Bot, Sparkles, AlertCircle } from 'lucide-react';
import { analyzeTeamPerformance } from '../services/geminiService';
import { MOCK_EMPLOYEES, DEPT_STATS } from '../constants';
import ReactMarkdown from 'react-markdown';

const AIAssistant: React.FC = () => {
  const [analysis, setAnalysis] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleAnalyze = async () => {
    setLoading(true);
    const result = await analyzeTeamPerformance(MOCK_EMPLOYEES, DEPT_STATS);
    setAnalysis(result);
    setLoading(false);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="bg-gradient-to-r from-indigo-600 to-violet-600 rounded-xl p-8 text-white shadow-lg">
        <div className="flex items-start gap-6">
          <div className="p-4 bg-white/20 rounded-xl backdrop-blur-sm">
            <Bot size={40} className="text-white" />
          </div>
          <div className="flex-1">
            <h2 className="text-2xl font-bold mb-2">AI 绩效分析师</h2>
            <p className="text-indigo-100 mb-6">
              利用 Google Gemini 2.5 模型分析部门 KPI，识别 Bizflow 数据中的风险点，并为数字产品经理和 UX 设计师生成可落地的辅导策略。
            </p>
            <button
              onClick={handleAnalyze}
              disabled={loading}
              className="bg-white text-indigo-600 px-6 py-3 rounded-lg font-bold shadow-md hover:bg-indigo-50 transition-colors flex items-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed"
            >
              {loading ? (
                <>
                  <div className="w-5 h-5 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
                  正在分析数据...
                </>
              ) : (
                <>
                  <Sparkles size={20} />
                  生成执行摘要报告
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {analysis && (
        <div className="bg-white rounded-xl shadow-md border border-slate-200 p-8 animate-fade-in">
          <h3 className="text-lg font-bold text-slate-800 mb-4 border-b border-slate-100 pb-2">分析结果</h3>
          <div className="prose prose-slate max-w-none">
            <ReactMarkdown>{analysis}</ReactMarkdown>
          </div>
          <div className="mt-6 pt-4 border-t border-slate-100 text-xs text-slate-400 flex items-center gap-2">
            <AlertCircle size={14} />
            <span>AI 生成的洞察基于当前的模拟数据快照。在进行人事决策前，请务必核实 Bizflow 原始日志。</span>
          </div>
        </div>
      )}
      
      {!analysis && !loading && (
        <div className="text-center py-12 text-slate-400">
          <div className="mb-2">点击上方按钮开始分析</div>
          <div className="text-xs">技术支持：Google Gemini 2.5 Flash</div>
        </div>
      )}
    </div>
  );
};

export default AIAssistant;