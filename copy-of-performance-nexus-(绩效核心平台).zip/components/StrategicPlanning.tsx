
import React from 'react';
import { Rocket, Zap, BrainCircuit, CheckCircle2, Flag, ArrowRight, Layers } from 'lucide-react';

const StrategicPlanning: React.FC = () => {
  const stages = [
    {
      id: 1,
      title: '第一阶段：自动化与可视化',
      subtitle: 'Automation & Visualization',
      icon: Layers,
      color: 'blue',
      delivery: '统一绩效看板上线，核心数据自动化采集。',
      success: '季度数据手工整理工作量减少 70%。',
      status: 'current'
    },
    {
      id: 2,
      title: '第二阶段：实时化与体系化',
      subtitle: 'Real-time & Systematization',
      icon: Zap,
      color: 'indigo',
      delivery: '全流程自动化闭环，实时过程管理与激励体系。',
      success: '关键数据实现零手工维护，过程管理效率提升 50%。',
      status: 'pending'
    },
    {
      id: 3,
      title: '第三阶段：智能化与生态化',
      subtitle: 'Intelligence & Ecosystem',
      icon: BrainCircuit,
      color: 'purple',
      delivery: 'AI智能分析预警，组织绩效知识库。',
      success: '平台成为业务决策的核心数据支持系统。',
      status: 'pending'
    }
  ];

  return (
    <div className="space-y-8 animate-fade-in pb-12">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end border-b border-slate-200 pb-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">项目落地战略规划</h2>
          <p className="text-sm text-slate-500">Bizflow Nexus 体系建设“三步走”战略路线图</p>
        </div>
        <div className="hidden md:flex items-center gap-2 text-sm font-medium text-slate-500 bg-slate-100 px-3 py-1 rounded-lg">
           <Flag size={16} className="text-blue-600"/>
           <span>当前进度：第一阶段攻坚中</span>
        </div>
      </div>

      {/* Main Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {stages.map((stage, index) => (
          <div 
            key={stage.id} 
            className={`relative rounded-xl border-2 transition-all duration-300 overflow-hidden flex flex-col ${
              stage.status === 'current' 
                ? 'bg-white border-blue-500 shadow-lg ring-4 ring-blue-50/50 transform scale-[1.02]' 
                : 'bg-white border-slate-200 shadow-sm hover:border-slate-300'
            }`}
          >
            {/* Stage Badge */}
            <div className={`absolute top-0 right-0 px-4 py-1.5 rounded-bl-xl text-xs font-bold uppercase tracking-wider ${
               stage.status === 'current' ? 'bg-blue-500 text-white' : 'bg-slate-100 text-slate-500'
            }`}>
               {stage.status === 'current' ? '进行中 (In Progress)' : `Phase 0${stage.id}`}
            </div>

            <div className="p-6 flex-1 flex flex-col">
              {/* Header */}
              <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-6 shadow-sm ${
                 stage.color === 'blue' ? 'bg-blue-100 text-blue-600' :
                 stage.color === 'indigo' ? 'bg-indigo-100 text-indigo-600' :
                 'bg-purple-100 text-purple-600'
              }`}>
                 <stage.icon size={28} />
              </div>

              <h3 className="text-xl font-bold text-slate-800 mb-1">{stage.title}</h3>
              <p className="text-xs text-slate-400 font-medium uppercase tracking-wide mb-6">{stage.subtitle}</p>

              {/* Content */}
              <div className="space-y-4 flex-1">
                 <div className="bg-slate-50 rounded-lg p-4 border border-slate-100">
                    <div className="text-xs text-slate-500 font-bold mb-2 uppercase flex items-center gap-1">
                       <Rocket size={12} /> 核心交付 (Deliverables)
                    </div>
                    <p className="text-sm text-slate-700 font-medium leading-relaxed">
                       {stage.delivery}
                    </p>
                 </div>

                 <div className={`rounded-lg p-4 border ${
                    stage.status === 'current' ? 'bg-blue-50 border-blue-100' : 'bg-emerald-50 border-emerald-100'
                 }`}>
                    <div className={`text-xs font-bold mb-2 uppercase flex items-center gap-1 ${
                       stage.status === 'current' ? 'text-blue-600' : 'text-emerald-600'
                    }`}>
                       <CheckCircle2 size={12} /> 成功标志 (Success Metrics)
                    </div>
                    <p className={`text-sm font-bold leading-relaxed ${
                       stage.status === 'current' ? 'text-blue-800' : 'text-emerald-800'
                    }`}>
                       {stage.success}
                    </p>
                 </div>
              </div>
            </div>

            {/* Progress Bar (Visual only) */}
            <div className="h-1.5 w-full bg-slate-100 mt-auto">
               <div 
                 className={`h-full ${
                    stage.color === 'blue' ? 'bg-blue-500' :
                    stage.color === 'indigo' ? 'bg-indigo-500' : 'bg-purple-500'
                 }`} 
                 style={{ width: stage.status === 'current' ? '60%' : '0%' }}
               ></div>
            </div>
          </div>
        ))}
      </div>

      {/* Connection Line (Visual Decoration) */}
      <div className="hidden lg:flex items-center justify-center gap-4 text-slate-300 mt-4">
         <div className="flex-1 h-px bg-slate-200"></div>
         <div className="text-xs font-medium uppercase tracking-widest text-slate-400">Evolution Path</div>
         <div className="flex-1 h-px bg-slate-200"></div>
      </div>

      {/* Summary Footer */}
      <div className="bg-slate-800 text-white rounded-xl p-8 shadow-xl mt-4 flex flex-col md:flex-row items-center justify-between gap-6">
         <div>
            <h4 className="text-lg font-bold mb-2 flex items-center gap-2">
               <Flag size={20} className="text-blue-400"/> 最终愿景
            </h4>
            <p className="text-slate-300 max-w-2xl">
               通过三个阶段的建设，Bizflow Nexus 将从一个单纯的数据看板，进化为驱动组织效能提升的智能引擎，彻底改变部门的绩效管理模式。
            </p>
         </div>
         <button className="bg-blue-600 hover:bg-blue-500 text-white px-6 py-3 rounded-lg font-bold transition-colors flex items-center gap-2 shadow-lg shadow-blue-900/50">
            查看详细执行路径 <ArrowRight size={18} />
         </button>
      </div>
    </div>
  );
};

export default StrategicPlanning;
