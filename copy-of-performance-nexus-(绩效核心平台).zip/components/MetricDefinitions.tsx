import React, { useState } from 'react';
import { Database, Calculator, Target, Palette, BookOpen, Table, AlertCircle, CheckCircle2, Clock, BarChart } from 'lucide-react';

interface MetricDetail {
  id: string;
  name: string;
  type: 'Result' | 'Process'; // 结果型 vs 过程型
  weight: string;
  definition: string;
  formula: string;
  dataSource: {
    system: string;
    table: string;
    fields: string[];
  };
  governance: string; // 数据治理/需补充项
}

const MetricDefinitions: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'PM' | 'UX'>('PM');

  const pmMetrics: MetricDetail[] = [
    {
      id: 'PM-01',
      name: '业务结果达成率',
      type: 'Result',
      weight: '40%',
      definition: '衡量项目交付后对核心业务目标（如GMV、转化率、用户增长）的实际拉动效果，是产品经理价值的核心体现。',
      formula: '( Σ(项目实际业务产出值) / Σ(项目预设目标值) ) × 100%',
      dataSource: {
        system: 'Bizflow',
        table: 'T_Project_Outcome',
        fields: ['target_value (目标值)', 'actual_value (实际值)', 'business_line_id (业务线)']
      },
      governance: '需在立项阶段强制录入“预计业务价值”，并在结项后30天内回填“实际值”。'
    },
    {
      id: 'PM-02',
      name: '项目交付量 (加权)',
      type: 'Result',
      weight: '30%',
      definition: '反映产品经理承接业务需求的吞吐能力，按项目难度等级进行加权计算。',
      formula: 'Σ (项目数量 × 等级系数)；系数标准：S级=3.0, A级=2.0, B级=1.0',
      dataSource: {
        system: 'Bizflow',
        table: 'T_Project_Main',
        fields: ['project_id', 'project_grade (S/A/B)', 'project_status (已投产)']
      },
      governance: 'S级项目需经过技术委员会定级确认，避免等级通胀。'
    },
    {
      id: 'PM-03',
      name: '项目交付及时率',
      type: 'Process',
      weight: '15%',
      definition: '衡量项目管理的计划性与执行力，是否按承诺时间上线。',
      formula: '( 按期投产项目数 / 总投产项目数 ) × 100%；按期定义：实际验收日 ≤ 计划验收日',
      dataSource: {
        system: 'Bizflow',
        table: 'T_Project_Milestones',
        fields: ['plan_uat_date', 'actual_uat_date', 'status']
      },
      governance: '计划变更需走审批流，否则以初始计划时间为准。'
    },
    {
      id: 'PM-04',
      name: '需求评审通过率',
      type: 'Process',
      weight: '15%',
      definition: '衡量PRD文档质量及需求思考的深度，减少研发返工。',
      formula: '( 一次评审通过的需求数 / 发起评审总数 ) × 100%',
      dataSource: {
        system: 'Bizflow',
        table: 'T_Requirement_Review',
        fields: ['review_id', 'review_rounds (轮次)', 'final_result (Pass/Fail)']
      },
      governance: '需区分“技术可行性评审”与“业务逻辑评审”，统称为需求评审。'
    }
  ];

  const uxMetrics: MetricDetail[] = [
    {
      id: 'UX-01',
      name: '设计验收通过率',
      type: 'Result',
      weight: '40%',
      definition: '衡量设计方案的落地质量及开发还原度，反映“设计稿”到“上线品”的保真能力。',
      formula: '( 一次验收通过数 / 总交付设计单数 ) × 100%',
      dataSource: {
        system: 'Bizflow',
        table: 'T_Design_Task',
        fields: ['task_id', 'acceptance_status (通过/驳回)', 'designer_id']
      },
      governance: 'Bizflow 需新增“验收状态”下拉字段，由前端负责人或PM勾选。'
    },
    {
      id: 'UX-02',
      name: '用户体验贡献值',
      type: 'Result',
      weight: '30%',
      definition: '量化设计优化带来的用户体验提升，通常与NPS或特定交互转化率挂钩。',
      formula: 'Σ (关联项目的体验指标提升幅度 × 项目权重) 或 季度NPS评分',
      dataSource: {
        system: 'SurveySys + Bizflow',
        table: 'T_Exp_Metrics',
        fields: ['nps_score', 'task_associated_metric_delta']
      },
      governance: '需建立设计单与体验指标的关联 ID，否则无法归因。'
    },
    {
      id: 'UX-03',
      name: '设计交付效率',
      type: 'Process',
      weight: '15%',
      definition: '衡量对业务需求的响应速度，特别是紧急需求的承接能力。',
      formula: '( 响应时长 ≤ 48h 的需求数 / 总需求数 ) × 100%',
      dataSource: {
        system: 'Bizflow',
        table: 'T_Design_Task_Log',
        fields: ['created_at (提需时间)', 'started_at (响应时间)']
      },
      governance: '系统需自动计算时间差，排除周末与节假日。'
    },
    {
      id: 'UX-04',
      name: '设计方案复用率',
      type: 'Process',
      weight: '15%',
      definition: '衡量设计规范化程度，鼓励使用设计系统组件，提升整体研发效能。',
      formula: '( 基于组件库创建的图层数 / 总图层数 ) 或 ( 复用组件的设计单数 / 总数 )',
      dataSource: {
        system: 'Figma Plugin -> Bizflow',
        table: 'T_Design_Assets',
        fields: ['is_component_based (Boolean)', 'asset_source']
      },
      governance: '目前需人工抽检或依赖 Figma 插件数据回传，初期可采用人工打标。'
    }
  ];

  const renderMetricCard = (metric: MetricDetail, colorClass: string, bgClass: string) => (
    <div key={metric.id} className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden hover:shadow-md transition-shadow">
      <div className={`px-6 py-4 border-b border-slate-100 flex justify-between items-start ${bgClass}`}>
        <div>
          <div className="flex items-center gap-2 mb-1">
            <h3 className={`font-bold text-lg text-slate-800`}>{metric.name}</h3>
            <span className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded border ${
              metric.type === 'Result' 
                ? 'bg-emerald-50 text-emerald-700 border-emerald-200' 
                : 'bg-slate-50 text-slate-600 border-slate-200'
            }`}>
              {metric.type === 'Result' ? '结果指标' : '过程指标'}
            </span>
          </div>
          <div className="text-xs text-slate-500 font-mono">{metric.id} • 建议权重 {metric.weight}</div>
        </div>
      </div>
      
      <div className="p-6 space-y-6">
        {/* Definition */}
        <div>
          <div className="flex items-center gap-2 text-sm font-bold text-slate-700 mb-2">
            <BookOpen size={16} className="text-slate-400"/> 指标定义
          </div>
          <p className="text-sm text-slate-600 leading-relaxed bg-slate-50 p-3 rounded-lg border border-slate-100">
            {metric.definition}
          </p>
        </div>

        {/* Formula */}
        <div>
          <div className="flex items-center gap-2 text-sm font-bold text-slate-700 mb-2">
            <Calculator size={16} className="text-slate-400"/> 计算逻辑 (Formula)
          </div>
          <div className="font-mono text-xs text-blue-700 bg-blue-50 px-3 py-2 rounded border border-blue-100 break-all">
            {metric.formula}
          </div>
        </div>

        {/* Data Source & Governance Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
           {/* Source */}
           <div>
              <div className="flex items-center gap-2 text-sm font-bold text-slate-700 mb-2">
                <Database size={16} className="text-slate-400"/> Bizflow 取数
              </div>
              <div className="text-xs text-slate-500 space-y-1">
                <div className="flex justify-between"><span className="text-slate-400">表:</span> <span className="font-mono text-slate-700">{metric.dataSource.table}</span></div>
                <div className="flex flex-col mt-1">
                  <span className="text-slate-400 mb-0.5">字段:</span> 
                  <div className="flex flex-wrap gap-1">
                    {metric.dataSource.fields.map(f => (
                      <span key={f} className="bg-slate-100 px-1.5 py-0.5 rounded text-slate-600 border border-slate-200">{f}</span>
                    ))}
                  </div>
                </div>
              </div>
           </div>

           {/* Governance */}
           <div>
              <div className="flex items-center gap-2 text-sm font-bold text-slate-700 mb-2">
                <AlertCircle size={16} className="text-amber-500"/> 数据治理/注意
              </div>
              <p className="text-xs text-slate-500 leading-tight">
                {metric.governance}
              </p>
           </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-8 animate-fade-in pb-12">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">指标定义体系字典</h2>
          <p className="text-slate-500">Bizflow Nexus 绩效评估标准全集 (KPI Dictionary)</p>
        </div>
        
        {/* Role Toggle */}
        <div className="bg-white p-1 rounded-xl border border-slate-200 shadow-sm flex">
          <button
            onClick={() => setActiveTab('PM')}
            className={`flex items-center gap-2 px-6 py-2.5 rounded-lg text-sm font-bold transition-all ${
              activeTab === 'PM'
                ? 'bg-blue-600 text-white shadow-md'
                : 'text-slate-500 hover:bg-slate-50'
            }`}
          >
            <Target size={18} />
            数字产品经理 (PM)
          </button>
          <button
            onClick={() => setActiveTab('UX')}
            className={`flex items-center gap-2 px-6 py-2.5 rounded-lg text-sm font-bold transition-all ${
              activeTab === 'UX'
                ? 'bg-purple-600 text-white shadow-md'
                : 'text-slate-500 hover:bg-slate-50'
            }`}
          >
            <Palette size={18} />
            UX 设计师
          </button>
        </div>
      </div>

      {/* Summary Stats for the Role */}
      <div className={`rounded-xl p-6 text-white shadow-lg ${activeTab === 'PM' ? 'bg-gradient-to-r from-blue-600 to-blue-500' : 'bg-gradient-to-r from-purple-600 to-purple-500'}`}>
         <div className="flex items-start gap-4">
            <div className="p-3 bg-white/20 rounded-lg">
               <Table size={24} className="text-white" />
            </div>
            <div>
               <h3 className="text-xl font-bold mb-1">
                 {activeTab === 'PM' ? '产品经理考核模型' : '设计师考核模型'}
               </h3>
               <p className="text-blue-50 text-sm opacity-90 max-w-2xl">
                 {activeTab === 'PM' 
                   ? '核心导向：以“业务结果”为第一优先级，兼顾项目交付的过程质量。数据主要来源于项目管理模块与经营分析模块。'
                   : '核心导向：以“产出质量”为核心，强调设计方案对用户体验的实际提升与开发还原度。'
                 }
               </p>
               <div className="mt-4 flex gap-6 text-sm font-medium">
                  <span className="flex items-center gap-1.5"><CheckCircle2 size={16} /> 结果指标权重: 70%</span>
                  <span className="flex items-center gap-1.5"><Clock size={16} /> 过程指标权重: 30%</span>
                  <span className="flex items-center gap-1.5"><BarChart size={16} /> 指标总数: 4个</span>
               </div>
            </div>
         </div>
      </div>

      {/* Metric Cards Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {activeTab === 'PM' 
          ? pmMetrics.map(m => renderMetricCard(m, 'text-blue-600', 'bg-blue-50/30'))
          : uxMetrics.map(m => renderMetricCard(m, 'text-purple-600', 'bg-purple-50/30'))
        }
      </div>

      <div className="bg-amber-50 border border-amber-100 rounded-lg p-4 flex items-start gap-3 text-sm text-amber-800">
         <AlertCircle size={18} className="mt-0.5 shrink-0" />
         <div>
            <span className="font-bold">关于数据治理的说明：</span>
            目前 Bizflow 系统中部分字段（如“实际业务产出”、“设计验收状态”）尚不完善。在系统字段开发完成前（预计 Q3），相关数据需由团队负责人在每月 5 日前通过 Excel 模板导入中间表。
         </div>
      </div>
    </div>
  );
};

export default MetricDefinitions;