import React from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  LineChart, Line, Legend, AreaChart, Area, Cell
} from 'recharts';
import { DEPT_STATS } from '../constants';
import { TrendingUp, TrendingDown, Users, CheckCircle, Briefcase, Layers } from 'lucide-react';

const dataDelivery = [
  { name: '1月', 计划: 12, 实际: 10 },
  { name: '2月', 计划: 15, 实际: 14 },
  { name: '3月', 计划: 18, 实际: 18 },
  { name: '4月', 计划: 20, 实际: 22 }, // exceeded
  { name: '5月', 计划: 22, 实际: 21 },
  { name: '6月', 计划: 25, 实际: 26 },
];

const dataBusinessLine = [
  { name: '核心电商', 达成率: 98.2, 目标: 95 },
  { name: '用户增长', 达成率: 92.0, 目标: 90 },
  { name: '商业化', 达成率: 85.5, 目标: 90 },
  { name: '创新业务', 达成率: 88.0, 目标: 85 },
];

const DashboardOverview: React.FC = () => {
  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex justify-between items-center">
        <div>
           <h2 className="text-2xl font-bold text-slate-800">部门指标看板</h2>
           <p className="text-sm text-slate-500 flex items-center gap-1">
             <Layers size={14}/> 步骤 3：基于已定义的口径聚合全景数据
           </p>
        </div>
        <span className="text-sm text-slate-500">最后更新: 刚刚 (来源: Bizflow)</span>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {DEPT_STATS.map((stat, index) => (
          <div key={index} className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
            <div className="text-sm font-medium text-slate-500 mb-2">{stat.label}</div>
            <div className="flex items-end justify-between">
              <div className="text-3xl font-bold text-slate-800">{stat.value}</div>
              <div className={`text-sm font-medium px-2 py-1 rounded-full ${
                stat.status === 'success' ? 'bg-emerald-100 text-emerald-700' :
                stat.status === 'warning' ? 'bg-amber-100 text-amber-700' :
                'bg-slate-100 text-slate-600'
              }`}>
                目标: {stat.target}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Business Line Performance Comparison */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 lg:col-span-2">
          <div className="mb-4 flex justify-between items-start">
            <div>
               <h3 className="text-lg font-bold text-slate-800">各业务线业绩达成率</h3>
               <p className="text-sm text-slate-500">聚合逻辑：SUM(各项目实际产出) / SUM(各项目目标)</p>
            </div>
            <div className="p-2 bg-blue-50 text-blue-600 rounded-lg">
               <Briefcase size={20} />
            </div>
          </div>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={dataBusinessLine} layout="vertical" margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#e2e8f0" />
                <XAxis type="number" domain={[0, 110]} hide />
                <YAxis dataKey="name" type="category" width={80} tick={{fontSize: 12}} />
                <Tooltip 
                  cursor={{fill: 'transparent'}}
                  contentStyle={{borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'}}
                />
                <Legend />
                <Bar dataKey="达成率" name="实际达成率(%)" barSize={20} radius={[0, 4, 4, 0]}>
                  {dataBusinessLine.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.达成率 >= entry.目标 ? '#10b981' : '#f59e0b'} />
                  ))}
                </Bar>
                <Bar dataKey="目标" name="目标基准(%)" barSize={20} radius={[0, 4, 4, 0]} fill="#cbd5e1" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Breakdown by Team/Role */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
          <div className="mb-4">
            <h3 className="text-lg font-bold text-slate-800">指标覆盖范围</h3>
            <p className="text-sm text-slate-500">涉及考核人员分布</p>
          </div>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-blue-500 rounded text-white"><Users size={18} /></div>
                <div>
                  <div className="font-bold text-slate-800">数字产品经理</div>
                  <div className="text-xs text-blue-600">聚焦指标：业务结果</div>
                </div>
              </div>
              <div className="text-2xl font-bold text-blue-700">12</div>
            </div>
            
            <div className="flex items-center justify-between p-4 bg-purple-50 rounded-lg">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-purple-500 rounded text-white"><CheckCircle size={18} /></div>
                <div>
                  <div className="font-bold text-slate-800">UX 设计师</div>
                  <div className="text-xs text-purple-600">聚焦指标：验收通过</div>
                </div>
              </div>
              <div className="text-2xl font-bold text-purple-700">8</div>
            </div>

            <div className="mt-6 pt-6 border-t border-slate-100">
                <h4 className="font-medium text-sm text-slate-600 mb-3">团队核心项目交付及时率</h4>
                <div className="w-full bg-slate-100 rounded-full h-2.5 mb-1">
                  <div className="bg-emerald-500 h-2.5 rounded-full" style={{ width: '98%' }}></div>
                </div>
                <div className="flex justify-between text-xs text-slate-500">
                   <span>98.2% (核心项目)</span>
                   <span>目标: 95%</span>
                </div>
            </div>
          </div>
        </div>

        {/* Project Delivery Trend */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 lg:col-span-3">
          <div className="mb-4">
            <h3 className="text-lg font-bold text-slate-800">过程指标趋势：项目交付</h3>
            <p className="text-sm text-slate-500">数据源：Bizflow Project_Milestones 表</p>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={dataDelivery} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorActual" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} />
                <YAxis axisLine={false} tickLine={false} />
                <Tooltip />
                <Legend />
                <Area type="monotone" dataKey="实际" stroke="#3b82f6" fillOpacity={1} fill="url(#colorActual)" />
                <Line type="monotone" dataKey="计划" stroke="#94a3b8" strokeDasharray="5 5" dot={false} strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardOverview;