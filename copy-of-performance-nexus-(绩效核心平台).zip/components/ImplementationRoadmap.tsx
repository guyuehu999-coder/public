
import React from 'react';
import { IMPLEMENTATION_PHASES } from '../constants';
import { CheckCircle2, Circle, Clock, Calendar, Users, PlayCircle, Map } from 'lucide-react';

const ImplementationRoadmap: React.FC = () => {
  return (
    <div className="space-y-6 animate-fade-in pb-12">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-slate-200 pb-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">实施路径图 (Roadmap)</h2>
          <p className="text-sm text-slate-500 flex items-center gap-1">
             <Map size={14} />
             Performance Nexus 落地推进计划：构建覆盖 100% 业务团队的绩效可视化体系
          </p>
        </div>
        <div className="flex items-center gap-3 text-sm">
           <div className="px-3 py-1 bg-emerald-50 text-emerald-700 rounded border border-emerald-100 font-medium flex items-center gap-1">
              <CheckCircle2 size={14}/> 已完成
           </div>
           <div className="px-3 py-1 bg-blue-50 text-blue-700 rounded border border-blue-100 font-medium flex items-center gap-1">
              <PlayCircle size={14}/> 进行中
           </div>
           <div className="px-3 py-1 bg-slate-50 text-slate-500 rounded border border-slate-200 font-medium flex items-center gap-1">
              <Circle size={14}/> 待启动
           </div>
        </div>
      </div>

      <div className="relative border-l-2 border-slate-200 ml-4 space-y-12 pb-8 mt-8">
        {IMPLEMENTATION_PHASES.map((phase, index) => (
          <div key={index} className="relative pl-8">
            {/* Timeline Dot */}
            <div className={`absolute -left-[11px] top-6 w-6 h-6 rounded-full border-4 flex items-center justify-center bg-white z-10 ${
              phase.status === 'completed' ? 'border-emerald-500' :
              phase.status === 'in-progress' ? 'border-blue-500 animate-pulse' :
              'border-slate-300'
            }`}>
              {phase.status === 'completed' && <div className="w-2 h-2 bg-emerald-500 rounded-full" />}
              {phase.status === 'in-progress' && <div className="w-2 h-2 bg-blue-500 rounded-full" />}
            </div>

            {/* Content Card */}
            <div className={`rounded-xl shadow-sm border overflow-hidden transition-all hover:shadow-md ${
               phase.status === 'in-progress' ? 'border-blue-200 ring-4 ring-blue-50/50' : 'border-slate-200 bg-white'
            }`}>
              {/* Card Header */}
              <div className={`px-6 py-4 border-b flex flex-col md:flex-row justify-between md:items-center gap-4 ${
                 phase.status === 'completed' ? 'bg-emerald-50/30 border-emerald-100' : 
                 phase.status === 'in-progress' ? 'bg-blue-50/30 border-blue-100' : 'bg-slate-50 border-slate-100'
              }`}>
                <div>
                   <h3 className={`font-bold text-lg ${
                     phase.status === 'completed' ? 'text-emerald-900' :
                     phase.status === 'in-progress' ? 'text-blue-900' : 'text-slate-700'
                   }`}>
                     {phase.title}
                   </h3>
                   {/* Only render metadata if it exists */}
                   {(phase.timeframe || phase.owner) && (
                       <div className="flex items-center gap-4 text-xs mt-1.5 opacity-80">
                          {phase.timeframe && <span className="flex items-center gap-1"><Calendar size={12}/> {phase.timeframe}</span>}
                          {phase.owner && <span className="flex items-center gap-1"><Users size={12}/> 责任人: {phase.owner}</span>}
                       </div>
                   )}
                </div>

                <div className="flex items-center gap-4">
                   <span className={`text-xs font-bold px-3 py-1.5 rounded uppercase tracking-wide border ${
                      phase.status === 'completed' ? 'bg-emerald-100 text-emerald-700 border-emerald-200' :
                      phase.status === 'in-progress' ? 'bg-blue-100 text-blue-700 border-blue-200' : 'bg-slate-100 text-slate-500 border-slate-200'
                   }`}>
                     {phase.status === 'completed' ? 'Completed' : phase.status === 'in-progress' ? 'In Progress' : 'Pending'}
                   </span>
                </div>
              </div>
              
              {/* Card Body */}
              <div className="p-6">
                <ul className="space-y-4">
                  {phase.items.map((item, i) => (
                    <li key={i} className="flex items-start gap-3 group">
                      <div className={`mt-0.5 ${
                         phase.status === 'completed' ? 'text-emerald-500' : 
                         phase.status === 'in-progress' ? 'text-blue-500' : 'text-slate-300'
                      }`}>
                         {phase.status === 'completed' ? <CheckCircle2 size={18} /> : 
                          phase.status === 'in-progress' ? <PlayCircle size={18} /> : <Circle size={18} />}
                      </div>
                      <span className={`text-sm leading-relaxed ${
                         phase.status === 'pending' ? 'text-slate-400' : 'text-slate-700'
                      }`}>
                         {item}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ImplementationRoadmap;
