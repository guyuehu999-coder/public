
import React, { useState } from 'react';
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  BarChart, Bar, Cell, LineChart, Line
} from 'recharts';
import { PRODUCT_DASHBOARD_DATA } from '../constants';
import { Rocket, Zap, ShieldCheck, TrendingUp, TrendingDown, Minus, CheckCircle, Clock, AlertTriangle, Briefcase, Activity, Target, GitPullRequest, AlertCircle, ListTodo, Bug, Eye, Settings, Plus } from 'lucide-react';

const ProductTeamDashboard: React.FC = () => {
  const { teamBusinessMetrics, featureTrends, projectDelivery } = PRODUCT_DASHBOARD_DATA;
  const [viewMode, setViewMode] = useState<'standard' | 'custom'>('standard');

  return (
    <div className="space-y-8 animate-fade-in pb-10">
      <div className="flex flex-col md:flex-row justify-between items-end border-b border-slate-200 pb-4 gap-4">
        <div>
           <h2 className="text-2xl font-bold text-slate-800">交易中台组 - 团队看板</h2>
           <p className="text-sm text-slate-500">部门：数字产品部 • 负责人视图 • 周期：2024年5月</p>
        </div>
        <div className="flex gap-3">
            {/* View Switcher Controls */}
            <div className="flex bg-slate-100 p-1 rounded-lg">
                <button 
                  onClick={() => setViewMode('standard')}
                  className={`px-3 py-1.5 text-sm rounded-md font-medium flex items-center gap-2 transition-all ${viewMode === 'standard' ? 'bg-white shadow-sm text-blue-700' : 'text-slate-500 hover:text-slate-700'}`}
                >
                  <Briefcase size={14} /> 组织标准视图
                </button>
                <button 
                   onClick={() => setViewMode('custom')}
                   className={`px-3 py-1.5 text-sm rounded-md font-medium flex items-center gap-2 transition-all ${viewMode === 'custom' ? 'bg-white shadow-sm text-purple-700' : 'text-slate-500 hover:text-slate-700'}`}
                >
                  <Settings size={14} /> 自定义关注
                </button>
            </div>
            <select className="bg-white border border-slate-300 text-slate-700 text-sm rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500">
                <option>交易管理平台</option>
                <option>客户管理平台</option>
            </select>
        </div>
      </div>

      {viewMode === 'standard' ? (
         <div className="bg-blue-50 border border-blue-100 text-blue-800 px-4 py-2 rounded-lg text-sm flex items-center gap-2">
            <Eye size={16} />
            当前为<strong>标准视图</strong>：已根据组织架构自动关联“GMV”、“转化率”及“交易管理平台”数据。数据将自动归档至年度绩效。
         </div>
      ) : (
         <div className="bg-purple-50 border border-purple-100 text-purple-800 px-4 py-2 rounded-lg text-sm flex items-center gap-2">
            <Settings size={16} />
            当前为<strong>自定义模式</strong>：您可以添加特定子指标或临时项目监控。此类配置仅对您个人可见。
         </div>
      )}

      {/* A. 团队业务核心指标 (With Header) */}
      <section>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-blue-100 text-blue-600 rounded-lg">
              <Target size={20} />
            </div>
            <h3 className="text-xl font-bold text-slate-800">一、团队业务核心指标</h3>
          </div>
          {viewMode === 'custom' && (
             <button className="text-xs bg-white border border-dashed border-slate-300 text-slate-500 px-3 py-1 rounded hover:border-purple-400 hover:text-purple-600 transition-colors flex items-center gap-1">
                <Plus size={12} /> 添加观测指标
             </button>
          )}
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {teamBusinessMetrics.map((metric, index) => (
            <div key={index} className="bg-white p-5 rounded-xl shadow-sm border border-slate-200 relative overflow-hidden">
               <div className="flex justify-between items-start mb-2">
                  <div className="text-sm text-slate-500">{metric.label}</div>
                  <div className={`text-xs font-bold px-1.5 py-0.5 rounded flex items-center gap-1 ${
                     metric.trend === 'up' ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-600'
                  }`}>
                     {metric.trend === 'up' ? <TrendingUp size={10} /> : <TrendingDown size={10} />}
                     {metric.change}
                  </div>
               </div>
               <div className="text-2xl font-bold text-slate-800 mb-4">{metric.value}</div>
               
               {/* Mini Sparkline Chart */}
               <div className="h-12 w-full absolute bottom-0 left-0 right-0 opacity-50">
                 <ResponsiveContainer width="100%" height="100%">
                   <AreaChart data={metric.data.map((val, i) => ({ i, val }))}>
                     <defs>
                       <linearGradient id={`grad-${index}`} x1="0" y1="0" x2="0" y2="1">
                         <stop offset="0%" stopColor={metric.trend === 'up' ? '#10b981' : '#ef4444'} stopOpacity={0.2}/>
                         <stop offset="100%" stopColor={metric.trend === 'up' ? '#10b981' : '#ef4444'} stopOpacity={0}/>
                       </linearGradient>
                     </defs>
                     <Area 
                       type="monotone" 
                       dataKey="val" 
                       stroke={metric.trend === 'up' ? '#10b981' : '#ef4444'} 
                       strokeWidth={2} 
                       fill={`url(#grad-${index})`} 
                     />
                   </AreaChart>
                 </ResponsiveContainer>
               </div>
            </div>
          ))}
          
          {/* Custom Mode Placeholder */}
          {viewMode === 'custom' && (
             <div className="border-2 border-dashed border-slate-200 rounded-xl flex flex-col items-center justify-center text-slate-400 p-5 hover:bg-slate-50 cursor-pointer transition-colors min-h-[140px]">
                <Plus size={24} className="mb-2" />
                <span className="text-xs font-medium">点击添加卡片</span>
             </div>
          )}
        </div>
      </section>

      {/* B. 核心功能使用趋势 (Larger Charts) */}
      <section className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="bg-slate-50 px-6 py-4 border-b border-slate-200 flex justify-between items-center">
          <h3 className="font-bold text-lg text-slate-800 flex items-center gap-2">
            <Rocket size={20} className="text-blue-600"/> 核心功能使用趋势监控
          </h3>
          <span className="text-xs bg-white border border-slate-200 px-2 py-1 rounded text-slate-500">2024年5月</span>
        </div>
        
        <div className="p-6">
          {/* 总体趋势大图 */}
          <div className="mb-8 pb-8 border-b border-slate-100">
             <div className="flex items-center gap-4 mb-4">
                <div className="text-base font-bold text-slate-700">平台整体活跃度</div>
                <span className="text-xs text-slate-400">环比 +{featureTrends.overall.wow}%</span>
             </div>
             <div className="h-48 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={featureTrends.chartData}>
                  <defs>
                    <linearGradient id="colorUsage" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9"/>
                  <XAxis dataKey="day" hide />
                  <Tooltip contentStyle={{borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'}}/>
                  <Area type="monotone" dataKey="value" stroke="#3b82f6" strokeWidth={2} fillOpacity={1} fill="url(#colorUsage)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* 各模块独立趋势图 - Expanded to 3 columns and taller height */}
          <div>
            <h4 className="font-bold text-sm text-slate-700 mb-4 flex items-center gap-2">
               <Activity size={16} className="text-slate-500"/> 各功能模块独立趋势
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
               {featureTrends.subTeams.map((team, idx) => (
                  <div key={idx} className="border border-slate-100 rounded-lg p-5 hover:shadow-md transition-shadow">
                     <div className="flex justify-between items-start mb-4">
                        <div className="font-bold text-slate-800">{team.name}</div>
                        <div className="text-right">
                           <div className="text-xl font-bold text-slate-800">{team.rate}%</div>
                           <div className={`text-xs font-bold ${team.trend >= 0 ? 'text-emerald-500' : 'text-red-500'}`}>
                              {team.trend >= 0 ? '↑' : '↓'} {Math.abs(team.trend)}%
                           </div>
                        </div>
                     </div>
                     {/* Taller Chart for better visibility */}
                     <div className="h-32 w-full">
                        <ResponsiveContainer width="100%" height="100%">
                           <LineChart data={team.history?.map((val, i) => ({ i, val })) || []}>
                              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9"/>
                              <Tooltip contentStyle={{borderRadius: '8px', border: 'none', fontSize: '12px'}} />
                              <Line type="monotone" dataKey="val" stroke={team.trend >= 0 ? '#10b981' : '#f43f5e'} strokeWidth={3} dot={{r: 3}} activeDot={{r: 5}} />
                           </LineChart>
                        </ResponsiveContainer>
                     </div>
                  </div>
               ))}
            </div>
          </div>
        </div>
      </section>

      {/* C. 重点项目与质量管理 (Separated Process & Quality) */}
      <section className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="bg-slate-50 px-6 py-4 border-b border-slate-200 flex justify-between items-center">
          <h3 className="font-bold text-lg text-slate-800 flex items-center gap-2">
            <Zap size={20} className="text-amber-500"/> 项目交付与质量全景
          </h3>
          <span className="text-xs bg-amber-50 border border-amber-100 text-amber-700 px-2 py-1 rounded">2024年 Q2</span>
        </div>

        <div className="p-6 space-y-8">
          
          {/* 1. 过程管控 (Process Management) */}
          <div>
             <h4 className="font-bold text-sm text-slate-700 mb-4 flex items-center gap-2">
                <ListTodo size={16} className="text-slate-500"/> 过程管控 (Process Control)
             </h4>
             <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-blue-50 border border-blue-100 rounded-lg p-4 flex items-center justify-between">
                   <div className="flex items-center gap-3">
                      <div className="p-2 bg-blue-200 text-blue-700 rounded-full"><GitPullRequest size={18}/></div>
                      <div>
                         <div className="text-xs text-blue-700 font-medium">待评审</div>
                         <div className="text-2xl font-bold text-blue-900">{projectDelivery.processStats?.pendingReview || 0}</div>
                      </div>
                   </div>
                </div>
                
                <div className="bg-indigo-50 border border-indigo-100 rounded-lg p-4 flex items-center justify-between">
                   <div className="flex items-center gap-3">
                      <div className="p-2 bg-indigo-200 text-indigo-700 rounded-full"><Clock size={18}/></div>
                      <div>
                         <div className="text-xs text-indigo-700 font-medium">开发中</div>
                         <div className="text-2xl font-bold text-indigo-900">{projectDelivery.processStats?.inDevelopment || 0}</div>
                      </div>
                   </div>
                </div>

                <div className="bg-purple-50 border border-purple-100 rounded-lg p-4 flex items-center justify-between">
                   <div className="flex items-center gap-3">
                      <div className="p-2 bg-purple-200 text-purple-700 rounded-full"><Bug size={18}/></div>
                      <div>
                         <div className="text-xs text-purple-700 font-medium">测试中</div>
                         <div className="text-2xl font-bold text-purple-900">{projectDelivery.processStats?.inTesting || 0}</div>
                      </div>
                   </div>
                </div>

                <div className="bg-red-50 border border-red-100 rounded-lg p-4 flex items-center justify-between">
                   <div className="flex items-center gap-3">
                      <div className="p-2 bg-red-200 text-red-700 rounded-full"><AlertTriangle size={18}/></div>
                      <div>
                         <div className="text-xs text-red-700 font-medium">严重延期</div>
                         <div className="text-2xl font-bold text-red-900">{projectDelivery.processStats?.delayed || 0}</div>
                      </div>
                   </div>
                </div>
             </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* 项目列表 (Simplified) */}
            <div className="lg:col-span-2">
              <h4 className="font-bold text-sm text-slate-700 mb-4">项目执行清单</h4>
              <div className="border border-slate-200 rounded-lg overflow-hidden">
                <table className="w-full text-sm text-left">
                  <thead className="text-xs text-slate-500 bg-slate-50 uppercase">
                    <tr>
                      <th className="px-4 py-3">等级</th>
                      <th className="px-4 py-3">项目名称</th>
                      <th className="px-4 py-3">负责人</th>
                      <th className="px-4 py-3 text-right">状态</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {projectDelivery.projects.map((p, i) => (
                      <tr key={i} className="hover:bg-slate-50">
                        <td className="px-4 py-3">
                          <span className={`px-1.5 py-0.5 rounded text-xs font-bold ${p.grade === 'S' ? 'bg-red-100 text-red-700' : 'bg-blue-100 text-blue-700'}`}>
                            {p.grade}
                          </span>
                        </td>
                        <td className="px-4 py-3 font-medium text-slate-700">{p.name}</td>
                        <td className="px-4 py-3 text-slate-500">{p.owner}</td>
                        <td className="px-4 py-3 text-right">
                          <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${
                            p.status === '待评审' ? 'bg-blue-100 text-blue-700' :
                            p.status === '延期' ? 'bg-red-100 text-red-700' : 
                            p.status === '已投产' ? 'bg-emerald-100 text-emerald-700' : 
                            'bg-slate-100 text-slate-700'
                          }`}>
                            {p.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* 2. 交付质量 (Separate Quality Metrics) */}
            <div className="bg-slate-50 rounded-lg p-5 border border-slate-100">
               <h4 className="font-bold text-sm text-slate-700 mb-4 flex items-center gap-2">
                 <ShieldCheck size={16}/> 交付质量监控
               </h4>
               
               <div className="space-y-6">
                  {/* Score */}
                  <div className="text-center p-4 bg-white rounded-lg border border-slate-200">
                     <div className="text-3xl font-bold text-amber-500">{projectDelivery.qualityStats?.avgFeedback || '-'}</div>
                     <div className="text-xs text-slate-400 mt-1">客户满意度均分 (满分5.0)</div>
                  </div>

                  {/* Metrics */}
                  <div className="space-y-3">
                     <div className="flex justify-between items-center text-sm border-b border-slate-200 pb-2">
                        <span className="text-slate-500">缺陷密度 (Bug/千行)</span>
                        <span className="font-bold text-slate-700">{projectDelivery.qualityStats?.bugDensity}</span>
                     </div>
                     <div className="flex justify-between items-center text-sm border-b border-slate-200 pb-2">
                        <span className="text-slate-500">缺陷重开率</span>
                        <span className="font-bold text-red-500">{projectDelivery.qualityStats?.reopenRate}%</span>
                     </div>
                     <div className="flex justify-between items-center text-sm">
                        <span className="text-slate-500">S级项目质量红线</span>
                        <span className="font-bold text-emerald-600">无触发</span>
                     </div>
                  </div>

                  <div className="bg-amber-50 p-3 rounded text-xs text-amber-700 flex gap-2">
                     <AlertCircle size={14} className="shrink-0 mt-0.5"/>
                     <span>注意：上周"评论模块"缺陷密度略有上升，建议加强Code Review。</span>
                  </div>
               </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ProductTeamDashboard;
