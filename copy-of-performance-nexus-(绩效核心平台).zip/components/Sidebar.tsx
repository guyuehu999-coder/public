
import React from 'react';
import { LayoutDashboard, Users, UserCircle, Trophy, Workflow, Bot, BarChart3, Network, Building2, FolderOpen, Map } from 'lucide-react';

interface SidebarProps {
  currentView: string;
  setCurrentView: (view: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentView, setCurrentView }) => {
  const menuItems = [
    { 
      category: '效能看板', // Renamed from '绩效管理' to reflect real-time/active monitoring
      items: [
        { id: 'cockpit', label: '管理层驾驶舱', icon: LayoutDashboard },
        { id: 'team-product', label: '产品团队看板', icon: Users },
        { id: 'personal', label: '个人工作台', icon: UserCircle },
      ]
    },
    {
      category: '部门中心',
      items: [
         { id: 'org-structure', label: '组织架构图', icon: Network },
         { id: 'leaderboard', label: '业绩排行榜', icon: Trophy },
         { id: 'archives', label: '绩效档案库', icon: FolderOpen },
      ]
    },
    {
      category: '工具与资源',
      items: [
        { id: 'strategy', label: '落地战略规划', icon: Map }, // New Item
        { id: 'roadmap', label: '实施路径图', icon: Workflow },
        { id: 'ai-analyst', label: 'AI 智能洞察', icon: Bot },
        { id: 'documentation', label: '指标定义体系', icon: BarChart3 },
      ]
    }
  ];

  return (
    <div className="w-64 bg-slate-900 text-white flex flex-col h-full fixed left-0 top-0 shadow-xl z-20">
      <div className="p-6 border-b border-slate-700">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-blue-500 rounded-lg flex items-center justify-center font-bold text-xl">P</div>
          <span className="text-xl font-bold tracking-tight">Performance Nexus</span>
        </div>
        <div className="mt-2 text-xs text-slate-400">绩效核心平台</div>
      </div>

      <nav className="flex-1 p-4 space-y-6 overflow-y-auto">
        {menuItems.map((group, idx) => (
          <div key={idx}>
            <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2 px-2">{group.category}</div>
            <div className="space-y-1">
              {group.items.map((item) => (
                <button
                  key={item.id}
                  onClick={() => setCurrentView(item.id)}
                  className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-lg transition-colors duration-200 text-sm ${
                    currentView === item.id
                      ? 'bg-blue-600 text-white shadow-md'
                      : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                  }`}
                >
                  <item.icon size={18} />
                  <span className="font-medium">{item.label}</span>
                </button>
              ))}
            </div>
          </div>
        ))}
      </nav>

      <div className="p-4 border-t border-slate-700">
        <div className="flex items-center gap-3 px-2 py-2">
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-blue-500 to-purple-500 flex items-center justify-center text-xs font-bold">
            W
          </div>
          <div>
            <div className="text-sm font-medium">王强</div>
            <div className="text-xs text-slate-400">产品总监</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
