
import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import ManagementCockpit from './components/ManagementCockpit';
import ProductTeamDashboard from './components/ProductTeamDashboard';
import PersonalWorkspace from './components/PersonalWorkspace';
import Leaderboard from './components/Leaderboard';
import ImplementationRoadmap from './components/ImplementationRoadmap';
import MetricDefinitions from './components/MetricDefinitions';
import AIAssistant from './components/AIAssistant';
import OrgStructure from './components/OrgStructure';
import DeptPerformanceArchives from './components/DeptPerformanceArchives';
import StrategicPlanning from './components/StrategicPlanning';
import { Bell, Search, User } from 'lucide-react';

const App: React.FC = () => {
  // Default view is now the Management Cockpit
  const [currentView, setCurrentView] = useState('cockpit');

  const renderContent = () => {
    switch (currentView) {
      case 'cockpit':
        return <ManagementCockpit />;
      case 'team-product':
        return <ProductTeamDashboard />;
      case 'personal':
        return <PersonalWorkspace />;
      case 'org-structure':
        return <OrgStructure />;
      case 'leaderboard':
        return <Leaderboard />;
      case 'archives':
        return <DeptPerformanceArchives />;
      case 'strategy':
        return <StrategicPlanning />;
      case 'roadmap':
        return <ImplementationRoadmap />;
      case 'ai-analyst':
        return <AIAssistant />;
      case 'documentation':
        return <MetricDefinitions />;
      default:
        return <ManagementCockpit />;
    }
  };

  return (
    <div className="flex min-h-screen bg-slate-50 font-sans">
      <Sidebar currentView={currentView} setCurrentView={setCurrentView} />
      
      <div className="ml-64 flex-1 flex flex-col">
        {/* Top Header */}
        <header className="h-16 bg-white border-b border-slate-200 sticky top-0 z-10 px-8 flex items-center justify-between">
          <div className="flex items-center text-slate-400 bg-slate-100 px-3 py-2 rounded-lg w-96">
            <Search size={18} className="mr-2" />
            <input 
              type="text" 
              placeholder="搜索项目、功能或员工..." 
              className="bg-transparent border-none outline-none text-sm w-full text-slate-700 placeholder-slate-400"
            />
          </div>
          
          <div className="flex items-center gap-6">
            <button className="relative text-slate-400 hover:text-slate-600">
              <Bell size={20} />
              <span className="absolute top-0 right-0 w-2 h-2 bg-red-500 rounded-full"></span>
            </button>
            <div className="flex items-center gap-3 pl-6 border-l border-slate-200">
              <div className="text-right">
                <div className="text-sm font-bold text-slate-800">王强</div>
                <div className="text-xs text-slate-500">产品总监</div>
              </div>
              <div className="w-10 h-10 bg-slate-200 rounded-full flex items-center justify-center text-slate-500">
                <User size={20} />
              </div>
            </div>
          </div>
        </header>

        {/* Main Content Area */}
        <main className="p-8 flex-1 overflow-y-auto">
          {renderContent()}
        </main>
      </div>
    </div>
  );
};

export default App;
